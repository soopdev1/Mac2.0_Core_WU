/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.db;

import static rc.so.util.Constant.test;
import static java.lang.Class.forName;
import java.sql.Connection;
import java.sql.DriverManager;
import static java.sql.DriverManager.getConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/**
 *
 * @author rcosco
 */
public class Db_Crm {

    Connection c = null;

    /**
     * Constructor
     */
    public Db_Crm() {
        try {
            String drivername = "org.XXXXXXXXX.jdbc.Driver";
            String typedb = "XXXXXXX";
            String user = "XXXXXXX";
            String pwd = "XXXXXXXXX";
            String host = "//machaproxy01.mactwo.loc:3306/mac_crm_prod";
            
            if (test) {
                host = "//machaproxy01.mactwo.loc:3306/mac_crm";
            }
            
            forName(drivername).newInstance();
            Properties p = new Properties();
            p.put("user", user);
            p.put("password", pwd);
            p.put("useUnicode", "true");
            p.put("characterEncoding", "UTF-8");
            p.put("useSSL", "false");
            this.c = getConnection("jdbc:" + typedb + ":" + host, p);
            this.c.createStatement().execute("SET GLOBAL max_allowed_packet=1024*1024*1024;");
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
            this.c = null;
            ex.printStackTrace();
        }
    }

    /**
     *
     * @return
     */
    public Connection getC() {
        return c;
    }

    /**
     *
     * @param c
     */
    public void setC(Connection c) {
        this.c = c;
    }

    /**
     * closeDB
     */
    public void closeDB() {
        try {
            if (this.c != null) {
                this.c.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    
    
    public String get_ValueSettings(String id) {
        try {
            String sql = "SELECT value FROM settings WHERE id = ?";
            PreparedStatement ps = this.c.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
}
