/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class C_CashierPerformance_value {
    String id_filiale, de_filiale,dataDa,dataA;

    String user, full, nTrans, nff, del, volume, comFix, err, totErr;
    
    ArrayList<C_CashierPerformance_value> dati;
    
    ArrayList<String> dati2;

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public String getFull() {
        return full;
    }

    /**
     *
     * @param full
     */
    public void setFull(String full) {
        this.full = full;
    }

    /**
     *
     * @return
     */
    public String getnTrans() {
        return nTrans;
    }

    /**
     *
     * @param nTrans
     */
    public void setnTrans(String nTrans) {
        this.nTrans = nTrans;
    }

    /**
     *
     * @return
     */
    public String getNff() {
        return nff;
    }

    /**
     *
     * @param nff
     */
    public void setNff(String nff) {
        this.nff = nff;
    }

    /**
     *
     * @return
     */
    public String getDel() {
        return del;
    }

    /**
     *
     * @param del
     */
    public void setDel(String del) {
        this.del = del;
    }

    /**
     *
     * @return
     */
    public String getVolume() {
        return volume;
    }

    /**
     *
     * @param volume
     */
    public void setVolume(String volume) {
        this.volume = volume;
    }

    /**
     *
     * @return
     */
    public String getComFix() {
        return comFix;
    }

    /**
     *
     * @param comFix
     */
    public void setComFix(String comFix) {
        this.comFix = comFix;
    }

    /**
     *
     * @return
     */
    public String getErr() {
        return err;
    }

    /**
     *
     * @param err
     */
    public void setErr(String err) {
        this.err = err;
    }

    /**
     *
     * @return
     */
    public String getTotErr() {
        return totErr;
    }

    /**
     *
     * @param totErr
     */
    public void setTotErr(String totErr) {
        this.totErr = totErr;
    }

    /**
     *
     * @return
     */
    public ArrayList<C_CashierPerformance_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<C_CashierPerformance_value> dati) {
        this.dati = dati;
    }

    /**
     *
     * @return
     */
    public ArrayList<String> getDati2() {
        return dati2;
    }

    /**
     *
     * @param dati2
     */
    public void setDati2(ArrayList<String> dati2) {
        this.dati2 = dati2;
    }
    

    
   
}
