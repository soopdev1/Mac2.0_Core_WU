/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

/**
 *
 * @author srotella
 */
public class C_CasherOpenCloseError_errore {
    
    String valuta, supporto, qtautente, qtasistema, cambio, contrdiff, note;

    /**
     *
     * @return
     */
    public String getValuta() {
        return valuta;
    }

    /**
     *
     * @param valuta
     */
    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    /**
     *
     * @return
     */
    public String getSupporto() {
        return supporto;
    }

    /**
     *
     * @param supporto
     */
    public void setSupporto(String supporto) {
        this.supporto = supporto;
    }

    /**
     *
     * @return
     */
    public String getQtautente() {
        return qtautente;
    }

    /**
     *
     * @param qtautente
     */
    public void setQtautente(String qtautente) {
        this.qtautente = qtautente;
    }

    /**
     *
     * @return
     */
    public String getQtasistema() {
        return qtasistema;
    }

    /**
     *
     * @param qtasistema
     */
    public void setQtasistema(String qtasistema) {
        this.qtasistema = qtasistema;
    }

    /**
     *
     * @return
     */
    public String getCambio() {
        return cambio;
    }

    /**
     *
     * @param cambio
     */
    public void setCambio(String cambio) {
        this.cambio = cambio;
    }

    /**
     *
     * @return
     */
    public String getContrdiff() {
        return contrdiff;
    }

    /**
     *
     * @param contrdiff
     */
    public void setContrdiff(String contrdiff) {
        this.contrdiff = contrdiff;
    }

    /**
     *
     * @return
     */
    public String getNote() {
        return note;
    }

    /**
     *
     * @param note
     */
    public void setNote(String note) {
        this.note = note;
    }
        
        
    
}
