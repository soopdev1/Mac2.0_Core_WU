/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class C_AnalysisCurrency_value {
    
    
    String dataDa, dataA;
    
    String id_filiale, de_filiale;

    String currency, fromBranch_qty, fromBranch_amount, buy_qty, buy_amount, fromBank_qty, fromBank_amount, openCloseError_qty, openCloseError_amount;
    String totalIn, totalAmountIn;
    String toBranch_qty, toBranch_amount, sell_qty, sell_amount, toBank_qty, toBank_amount;
    String totOut, totAmountOut;
    
    ArrayList<C_AnalysisCurrency_value> dati;

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return
     */
    public String getFromBranch_qty() {
        return fromBranch_qty;
    }

    /**
     *
     * @param fromBranch_qty
     */
    public void setFromBranch_qty(String fromBranch_qty) {
        this.fromBranch_qty = fromBranch_qty;
    }

    /**
     *
     * @return
     */
    public String getFromBranch_amount() {
        return fromBranch_amount;
    }

    /**
     *
     * @param fromBranch_amount
     */
    public void setFromBranch_amount(String fromBranch_amount) {
        this.fromBranch_amount = fromBranch_amount;
    }

    /**
     *
     * @return
     */
    public String getBuy_qty() {
        return buy_qty;
    }

    /**
     *
     * @param buy_qty
     */
    public void setBuy_qty(String buy_qty) {
        this.buy_qty = buy_qty;
    }

    /**
     *
     * @return
     */
    public String getBuy_amount() {
        return buy_amount;
    }

    /**
     *
     * @param buy_amount
     */
    public void setBuy_amount(String buy_amount) {
        this.buy_amount = buy_amount;
    }

    /**
     *
     * @return
     */
    public String getFromBank_qty() {
        return fromBank_qty;
    }

    /**
     *
     * @param fromBank_qty
     */
    public void setFromBank_qty(String fromBank_qty) {
        this.fromBank_qty = fromBank_qty;
    }

    /**
     *
     * @return
     */
    public String getFromBank_amount() {
        return fromBank_amount;
    }

    /**
     *
     * @param fromBank_amount
     */
    public void setFromBank_amount(String fromBank_amount) {
        this.fromBank_amount = fromBank_amount;
    }

    /**
     *
     * @return
     */
    public String getOpenCloseError_qty() {
        return openCloseError_qty;
    }

    /**
     *
     * @param openCloseError_qty
     */
    public void setOpenCloseError_qty(String openCloseError_qty) {
        this.openCloseError_qty = openCloseError_qty;
    }

    /**
     *
     * @return
     */
    public String getOpenCloseError_amount() {
        return openCloseError_amount;
    }

    /**
     *
     * @param openCloseError_amount
     */
    public void setOpenCloseError_amount(String openCloseError_amount) {
        this.openCloseError_amount = openCloseError_amount;
    }

    /**
     *
     * @return
     */
    public String getTotalIn() {
        return totalIn;
    }

    /**
     *
     * @param totalIn
     */
    public void setTotalIn(String totalIn) {
        this.totalIn = totalIn;
    }

    /**
     *
     * @return
     */
    public String getTotalAmountIn() {
        return totalAmountIn;
    }

    /**
     *
     * @param totalAmountIn
     */
    public void setTotalAmountIn(String totalAmountIn) {
        this.totalAmountIn = totalAmountIn;
    }

    /**
     *
     * @return
     */
    public String getToBranch_qty() {
        return toBranch_qty;
    }

    /**
     *
     * @param toBranch_qty
     */
    public void setToBranch_qty(String toBranch_qty) {
        this.toBranch_qty = toBranch_qty;
    }

    /**
     *
     * @return
     */
    public String getToBranch_amount() {
        return toBranch_amount;
    }

    /**
     *
     * @param toBranch_amount
     */
    public void setToBranch_amount(String toBranch_amount) {
        this.toBranch_amount = toBranch_amount;
    }

    /**
     *
     * @return
     */
    public String getSell_qty() {
        return sell_qty;
    }

    /**
     *
     * @param sell_qty
     */
    public void setSell_qty(String sell_qty) {
        this.sell_qty = sell_qty;
    }

    /**
     *
     * @return
     */
    public String getSell_amount() {
        return sell_amount;
    }

    /**
     *
     * @param sell_amount
     */
    public void setSell_amount(String sell_amount) {
        this.sell_amount = sell_amount;
    }

    /**
     *
     * @return
     */
    public String getToBank_qty() {
        return toBank_qty;
    }

    /**
     *
     * @param toBank_qty
     */
    public void setToBank_qty(String toBank_qty) {
        this.toBank_qty = toBank_qty;
    }

    /**
     *
     * @return
     */
    public String getToBank_amount() {
        return toBank_amount;
    }

    /**
     *
     * @param toBank_amount
     */
    public void setToBank_amount(String toBank_amount) {
        this.toBank_amount = toBank_amount;
    }

    /**
     *
     * @return
     */
    public String getTotOut() {
        return totOut;
    }

    /**
     *
     * @param totOut
     */
    public void setTotOut(String totOut) {
        this.totOut = totOut;
    }

    /**
     *
     * @return
     */
    public String getTotAmountOut() {
        return totAmountOut;
    }

    /**
     *
     * @param totAmountOut
     */
    public void setTotAmountOut(String totAmountOut) {
        this.totAmountOut = totAmountOut;
    }

    /**
     *
     * @return
     */
    public ArrayList<C_AnalysisCurrency_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<C_AnalysisCurrency_value> dati) {
        this.dati = dati;
    }
    
}
