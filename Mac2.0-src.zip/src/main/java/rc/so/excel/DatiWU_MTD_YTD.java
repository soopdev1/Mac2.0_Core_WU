/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.excel;

import org.joda.time.DateTime;

/**
 *
 * @author rcosco
 */
public class DatiWU_MTD_YTD {
    
    
    String filiale;
    String descr;
    
    DateTime datastart;
    DateTime dataend;
    
    String volumesend,volumesend_prevyear,volumerec,volumerec_prevyear, volumetot, volumetot_prevyear, trsend,trsend_prevyear, trrec, trrec_prevyear, trtot,trtot_prevyear;

    /**
     *
     * @return
     */
    public String getFiliale() {
        return filiale;
    }

    /**
     *
     * @param filiale
     */
    public void setFiliale(String filiale) {
        this.filiale = filiale;
    }

    /**
     *
     * @return
     */
    public String getDescr() {
        return descr;
    }

    /**
     *
     * @param descr
     */
    public void setDescr(String descr) {
        this.descr = descr;
    }

    /**
     *
     * @return
     */
    public DateTime getDatastart() {
        return datastart;
    }

    /**
     *
     * @param datastart
     */
    public void setDatastart(DateTime datastart) {
        this.datastart = datastart;
    }

    /**
     *
     * @return
     */
    public DateTime getDataend() {
        return dataend;
    }

    /**
     *
     * @param dataend
     */
    public void setDataend(DateTime dataend) {
        this.dataend = dataend;
    }

    /**
     *
     * @return
     */
    public String getVolumesend() {
        return volumesend;
    }

    /**
     *
     * @param volumesend
     */
    public void setVolumesend(String volumesend) {
        this.volumesend = volumesend;
    }

    /**
     *
     * @return
     */
    public String getVolumesend_prevyear() {
        return volumesend_prevyear;
    }

    /**
     *
     * @param volumesend_prevyear
     */
    public void setVolumesend_prevyear(String volumesend_prevyear) {
        this.volumesend_prevyear = volumesend_prevyear;
    }

    /**
     *
     * @return
     */
    public String getVolumerec() {
        return volumerec;
    }

    /**
     *
     * @param volumerec
     */
    public void setVolumerec(String volumerec) {
        this.volumerec = volumerec;
    }

    /**
     *
     * @return
     */
    public String getVolumerec_prevyear() {
        return volumerec_prevyear;
    }

    /**
     *
     * @param volumerec_prevyear
     */
    public void setVolumerec_prevyear(String volumerec_prevyear) {
        this.volumerec_prevyear = volumerec_prevyear;
    }

    /**
     *
     * @return
     */
    public String getVolumetot() {
        return volumetot;
    }

    /**
     *
     * @param volumetot
     */
    public void setVolumetot(String volumetot) {
        this.volumetot = volumetot;
    }

    /**
     *
     * @return
     */
    public String getVolumetot_prevyear() {
        return volumetot_prevyear;
    }

    /**
     *
     * @param volumetot_prevyear
     */
    public void setVolumetot_prevyear(String volumetot_prevyear) {
        this.volumetot_prevyear = volumetot_prevyear;
    }

    /**
     *
     * @return
     */
    public String getTrsend() {
        return trsend;
    }

    /**
     *
     * @param trsend
     */
    public void setTrsend(String trsend) {
        this.trsend = trsend;
    }

    /**
     *
     * @return
     */
    public String getTrsend_prevyear() {
        return trsend_prevyear;
    }

    /**
     *
     * @param trsend_prevyear
     */
    public void setTrsend_prevyear(String trsend_prevyear) {
        this.trsend_prevyear = trsend_prevyear;
    }

    /**
     *
     * @return
     */
    public String getTrrec() {
        return trrec;
    }

    /**
     *
     * @param trrec
     */
    public void setTrrec(String trrec) {
        this.trrec = trrec;
    }

    /**
     *
     * @return
     */
    public String getTrrec_prevyear() {
        return trrec_prevyear;
    }

    /**
     *
     * @param trrec_prevyear
     */
    public void setTrrec_prevyear(String trrec_prevyear) {
        this.trrec_prevyear = trrec_prevyear;
    }

    /**
     *
     * @return
     */
    public String getTrtot() {
        return trtot;
    }

    /**
     *
     * @param trtot
     */
    public void setTrtot(String trtot) {
        this.trtot = trtot;
    }

    /**
     *
     * @return
     */
    public String getTrtot_prevyear() {
        return trtot_prevyear;
    }

    /**
     *
     * @param trtot_prevyear
     */
    public void setTrtot_prevyear(String trtot_prevyear) {
        this.trtot_prevyear = trtot_prevyear;
    }
    
    
    
    
    
    
    
}
