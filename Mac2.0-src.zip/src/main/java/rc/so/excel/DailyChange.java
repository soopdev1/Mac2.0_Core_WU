/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.excel;

/**
 *
 * @author rcosco
 */
public class DailyChange {
    
    String filiale,descr,data,VOLUMEAC,VOLUMECA,VOLUMETC,TRANSAC,TRANSCA,TRANSTC,COMMAC,COMMCA,COMMTC,SPREADBR,SPREADBA,SPREADAC,SPREADCA;
    
    String TOTTRANSACQ,TOTVOLACQ,TOTGMACQ,PERCACQ;
    String VOLUMEVENDOFF,VOLUMEONL,VOLUMERIVA,TRANSVENDOFF,TRANSONL,TRANSRIVA,COMMVENDOFF,COMMONL,COMMRIVA,SPREADVEND;
    String TOTTRANSVEN,TOTVOLVEN,TOTGMVEN,PERCVEN;
    String TOTVOL,TOTTRANS,TOTGM,PERCVEND;
    String COP,TOBANKCOP,FRBANKCOP,TOBRCOP,FRBRCOP,OCERRCOP;
    String FX,TOBANKFX,FRBANKFX,TOBRFX,FRBRFX,OCERRFX;

    /**
     * Constructor
     */
    public DailyChange() {
    }

    /**
     *
     * @return
     */
    public String getFiliale() {
        return filiale;
    }

    /**
     *
     * @param filiale
     */
    public void setFiliale(String filiale) {
        this.filiale = filiale;
    }

    /**
     *
     * @return
     */
    public String getDescr() {
        return descr;
    }

    /**
     *
     * @param descr
     */
    public void setDescr(String descr) {
        this.descr = descr;
    }

    /**
     *
     * @return
     */
    public String getData() {
        return data;
    }

    /**
     *
     * @param data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     *
     * @return
     */
    public String getVOLUMEAC() {
        return VOLUMEAC;
    }

    /**
     *
     * @param VOLUMEAC
     */
    public void setVOLUMEAC(String VOLUMEAC) {
        this.VOLUMEAC = VOLUMEAC;
    }

    /**
     *
     * @return
     */
    public String getVOLUMECA() {
        return VOLUMECA;
    }

    /**
     *
     * @param VOLUMECA
     */
    public void setVOLUMECA(String VOLUMECA) {
        this.VOLUMECA = VOLUMECA;
    }

    /**
     *
     * @return
     */
    public String getVOLUMETC() {
        return VOLUMETC;
    }

    /**
     *
     * @param VOLUMETC
     */
    public void setVOLUMETC(String VOLUMETC) {
        this.VOLUMETC = VOLUMETC;
    }

    /**
     *
     * @return
     */
    public String getTRANSAC() {
        return TRANSAC;
    }

    /**
     *
     * @param TRANSAC
     */
    public void setTRANSAC(String TRANSAC) {
        this.TRANSAC = TRANSAC;
    }

    /**
     *
     * @return
     */
    public String getTRANSCA() {
        return TRANSCA;
    }

    /**
     *
     * @param TRANSCA
     */
    public void setTRANSCA(String TRANSCA) {
        this.TRANSCA = TRANSCA;
    }

    /**
     *
     * @return
     */
    public String getTRANSTC() {
        return TRANSTC;
    }

    /**
     *
     * @param TRANSTC
     */
    public void setTRANSTC(String TRANSTC) {
        this.TRANSTC = TRANSTC;
    }

    /**
     *
     * @return
     */
    public String getCOMMAC() {
        return COMMAC;
    }

    /**
     *
     * @param COMMAC
     */
    public void setCOMMAC(String COMMAC) {
        this.COMMAC = COMMAC;
    }

    /**
     *
     * @return
     */
    public String getCOMMCA() {
        return COMMCA;
    }

    /**
     *
     * @param COMMCA
     */
    public void setCOMMCA(String COMMCA) {
        this.COMMCA = COMMCA;
    }

    /**
     *
     * @return
     */
    public String getCOMMTC() {
        return COMMTC;
    }

    /**
     *
     * @param COMMTC
     */
    public void setCOMMTC(String COMMTC) {
        this.COMMTC = COMMTC;
    }

    /**
     *
     * @return
     */
    public String getSPREADBR() {
        return SPREADBR;
    }

    /**
     *
     * @param SPREADBR
     */
    public void setSPREADBR(String SPREADBR) {
        this.SPREADBR = SPREADBR;
    }

    /**
     *
     * @return
     */
    public String getSPREADBA() {
        return SPREADBA;
    }

    /**
     *
     * @param SPREADBA
     */
    public void setSPREADBA(String SPREADBA) {
        this.SPREADBA = SPREADBA;
    }

    /**
     *
     * @return
     */
    public String getTOTTRANSACQ() {
        return TOTTRANSACQ;
    }

    /**
     *
     * @param TOTTRANSACQ
     */
    public void setTOTTRANSACQ(String TOTTRANSACQ) {
        this.TOTTRANSACQ = TOTTRANSACQ;
    }

    /**
     *
     * @return
     */
    public String getTOTVOLACQ() {
        return TOTVOLACQ;
    }

    /**
     *
     * @param TOTVOLACQ
     */
    public void setTOTVOLACQ(String TOTVOLACQ) {
        this.TOTVOLACQ = TOTVOLACQ;
    }

    /**
     *
     * @return
     */
    public String getTOTGMACQ() {
        return TOTGMACQ;
    }

    /**
     *
     * @param TOTGMACQ
     */
    public void setTOTGMACQ(String TOTGMACQ) {
        this.TOTGMACQ = TOTGMACQ;
    }

    /**
     *
     * @return
     */
    public String getPERCACQ() {
        return PERCACQ;
    }

    /**
     *
     * @param PERCACQ
     */
    public void setPERCACQ(String PERCACQ) {
        this.PERCACQ = PERCACQ;
    }

    /**
     *
     * @return
     */
    public String getVOLUMEVENDOFF() {
        return VOLUMEVENDOFF;
    }

    /**
     *
     * @param VOLUMEVENDOFF
     */
    public void setVOLUMEVENDOFF(String VOLUMEVENDOFF) {
        this.VOLUMEVENDOFF = VOLUMEVENDOFF;
    }

    /**
     *
     * @return
     */
    public String getVOLUMEONL() {
        return VOLUMEONL;
    }

    /**
     *
     * @param VOLUMEONL
     */
    public void setVOLUMEONL(String VOLUMEONL) {
        this.VOLUMEONL = VOLUMEONL;
    }

    /**
     *
     * @return
     */
    public String getVOLUMERIVA() {
        return VOLUMERIVA;
    }

    /**
     *
     * @param VOLUMERIVA
     */
    public void setVOLUMERIVA(String VOLUMERIVA) {
        this.VOLUMERIVA = VOLUMERIVA;
    }

    /**
     *
     * @return
     */
    public String getTRANSVENDOFF() {
        return TRANSVENDOFF;
    }

    /**
     *
     * @param TRANSVENDOFF
     */
    public void setTRANSVENDOFF(String TRANSVENDOFF) {
        this.TRANSVENDOFF = TRANSVENDOFF;
    }

    /**
     *
     * @return
     */
    public String getTRANSONL() {
        return TRANSONL;
    }

    /**
     *
     * @param TRANSONL
     */
    public void setTRANSONL(String TRANSONL) {
        this.TRANSONL = TRANSONL;
    }

    /**
     *
     * @return
     */
    public String getTRANSRIVA() {
        return TRANSRIVA;
    }

    /**
     *
     * @param TRANSRIVA
     */
    public void setTRANSRIVA(String TRANSRIVA) {
        this.TRANSRIVA = TRANSRIVA;
    }

    /**
     *
     * @return
     */
    public String getCOMMVENDOFF() {
        return COMMVENDOFF;
    }

    /**
     *
     * @param COMMVENDOFF
     */
    public void setCOMMVENDOFF(String COMMVENDOFF) {
        this.COMMVENDOFF = COMMVENDOFF;
    }

    /**
     *
     * @return
     */
    public String getCOMMONL() {
        return COMMONL;
    }

    /**
     *
     * @param COMMONL
     */
    public void setCOMMONL(String COMMONL) {
        this.COMMONL = COMMONL;
    }

    /**
     *
     * @return
     */
    public String getCOMMRIVA() {
        return COMMRIVA;
    }

    /**
     *
     * @param COMMRIVA
     */
    public void setCOMMRIVA(String COMMRIVA) {
        this.COMMRIVA = COMMRIVA;
    }

    /**
     *
     * @return
     */
    public String getSPREADVEND() {
        return SPREADVEND;
    }

    /**
     *
     * @param SPREADVEND
     */
    public void setSPREADVEND(String SPREADVEND) {
        this.SPREADVEND = SPREADVEND;
    }

    /**
     *
     * @return
     */
    public String getTOTTRANSVEN() {
        return TOTTRANSVEN;
    }

    /**
     *
     * @param TOTTRANSVEN
     */
    public void setTOTTRANSVEN(String TOTTRANSVEN) {
        this.TOTTRANSVEN = TOTTRANSVEN;
    }

    /**
     *
     * @return
     */
    public String getTOTVOLVEN() {
        return TOTVOLVEN;
    }

    /**
     *
     * @param TOTVOLVEN
     */
    public void setTOTVOLVEN(String TOTVOLVEN) {
        this.TOTVOLVEN = TOTVOLVEN;
    }

    /**
     *
     * @return
     */
    public String getTOTGMVEN() {
        return TOTGMVEN;
    }

    /**
     *
     * @param TOTGMVEN
     */
    public void setTOTGMVEN(String TOTGMVEN) {
        this.TOTGMVEN = TOTGMVEN;
    }

    /**
     *
     * @return
     */
    public String getPERCVEN() {
        return PERCVEN;
    }

    /**
     *
     * @param PERCVEN
     */
    public void setPERCVEN(String PERCVEN) {
        this.PERCVEN = PERCVEN;
    }

    /**
     *
     * @return
     */
    public String getTOTVOL() {
        return TOTVOL;
    }

    /**
     *
     * @param TOTVOL
     */
    public void setTOTVOL(String TOTVOL) {
        this.TOTVOL = TOTVOL;
    }

    /**
     *
     * @return
     */
    public String getTOTTRANS() {
        return TOTTRANS;
    }

    /**
     *
     * @param TOTTRANS
     */
    public void setTOTTRANS(String TOTTRANS) {
        this.TOTTRANS = TOTTRANS;
    }

    /**
     *
     * @return
     */
    public String getTOTGM() {
        return TOTGM;
    }

    /**
     *
     * @param TOTGM
     */
    public void setTOTGM(String TOTGM) {
        this.TOTGM = TOTGM;
    }

    /**
     *
     * @return
     */
    public String getPERCVEND() {
        return PERCVEND;
    }

    /**
     *
     * @param PERCVEND
     */
    public void setPERCVEND(String PERCVEND) {
        this.PERCVEND = PERCVEND;
    }

    /**
     *
     * @return
     */
    public String getCOP() {
        return COP;
    }

    /**
     *
     * @param COP
     */
    public void setCOP(String COP) {
        this.COP = COP;
    }

    /**
     *
     * @return
     */
    public String getTOBANKCOP() {
        return TOBANKCOP;
    }

    /**
     *
     * @param TOBANKCOP
     */
    public void setTOBANKCOP(String TOBANKCOP) {
        this.TOBANKCOP = TOBANKCOP;
    }

    /**
     *
     * @return
     */
    public String getFRBANKCOP() {
        return FRBANKCOP;
    }

    /**
     *
     * @param FRBANKCOP
     */
    public void setFRBANKCOP(String FRBANKCOP) {
        this.FRBANKCOP = FRBANKCOP;
    }

    /**
     *
     * @return
     */
    public String getTOBRCOP() {
        return TOBRCOP;
    }

    /**
     *
     * @param TOBRCOP
     */
    public void setTOBRCOP(String TOBRCOP) {
        this.TOBRCOP = TOBRCOP;
    }

    /**
     *
     * @return
     */
    public String getFRBRCOP() {
        return FRBRCOP;
    }

    /**
     *
     * @param FRBRCOP
     */
    public void setFRBRCOP(String FRBRCOP) {
        this.FRBRCOP = FRBRCOP;
    }

    /**
     *
     * @return
     */
    public String getOCERRCOP() {
        return OCERRCOP;
    }

    /**
     *
     * @param OCERRCOP
     */
    public void setOCERRCOP(String OCERRCOP) {
        this.OCERRCOP = OCERRCOP;
    }

    /**
     *
     * @return
     */
    public String getFX() {
        return FX;
    }

    /**
     *
     * @param FX
     */
    public void setFX(String FX) {
        this.FX = FX;
    }

    /**
     *
     * @return
     */
    public String getTOBANKFX() {
        return TOBANKFX;
    }

    /**
     *
     * @param TOBANKFX
     */
    public void setTOBANKFX(String TOBANKFX) {
        this.TOBANKFX = TOBANKFX;
    }

    /**
     *
     * @return
     */
    public String getFRBANKFX() {
        return FRBANKFX;
    }

    /**
     *
     * @param FRBANKFX
     */
    public void setFRBANKFX(String FRBANKFX) {
        this.FRBANKFX = FRBANKFX;
    }

    /**
     *
     * @return
     */
    public String getTOBRFX() {
        return TOBRFX;
    }

    /**
     *
     * @param TOBRFX
     */
    public void setTOBRFX(String TOBRFX) {
        this.TOBRFX = TOBRFX;
    }

    /**
     *
     * @return
     */
    public String getFRBRFX() {
        return FRBRFX;
    }

    /**
     *
     * @param FRBRFX
     */
    public void setFRBRFX(String FRBRFX) {
        this.FRBRFX = FRBRFX;
    }

    /**
     *
     * @return
     */
    public String getOCERRFX() {
        return OCERRFX;
    }

    /**
     *
     * @param OCERRFX
     */
    public void setOCERRFX(String OCERRFX) {
        this.OCERRFX = OCERRFX;
    }

    public String getSPREADAC() {
        return SPREADAC;
    }

    public void setSPREADAC(String SPREADAC) {
        this.SPREADAC = SPREADAC;
    }

    public String getSPREADCA() {
        return SPREADCA;
    }

    public void setSPREADCA(String SPREADCA) {
        this.SPREADCA = SPREADCA;
    }
    
    
    
    

    
}
