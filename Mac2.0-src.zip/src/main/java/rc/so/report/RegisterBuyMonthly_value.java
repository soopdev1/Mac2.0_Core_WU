/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class RegisterBuyMonthly_value {

    ArrayList<RegisterBuyMonthly_value> dati;

    String id_filiale, de_filiale, tipocliente, valuta, acqclienti, controvalore, saldovaluta;
    String trasfdadip1, trasfdadip2, trasfdaban1, trasfdaban2;

    /**
     *
     * @return
     */
    public String getTrasfdadip1() {
        return (trasfdadip1);
    }

    /**
     *
     * @return
     */
    public String getTrasfdadip1SenzaFormattazione() {
        return (trasfdadip1);
    }

    /**
     *
     * @param trasfdadip1
     */
    public void setTrasfdadip1(String trasfdadip1) {
        this.trasfdadip1 = trasfdadip1;
    }

    /**
     *
     * @return
     */
    public String getTrasfdadip2() {
        return (trasfdadip2);
    }

    /**
     *
     * @return
     */
    public String getTrasfdadip2SenzaFormattazione() {
        return (trasfdadip2);
    }

    /**
     *
     * @param trasfdadip2
     */
    public void setTrasfdadip2(String trasfdadip2) {
        this.trasfdadip2 = trasfdadip2;
    }

    /**
     *
     * @return
     */
    public String getTrasfdaban1() {
        return (trasfdaban1);
    }

    /**
     *
     * @return
     */
    public String getTrasfdaban1SenzaFormattazione() {
        return (trasfdaban1);
    }

    /**
     *
     * @param trasfdaban1
     */
    public void setTrasfdaban1(String trasfdaban1) {
        this.trasfdaban1 = trasfdaban1;
    }

    /**
     *
     * @return
     */
    public String getTrasfdaban2() {
        return (trasfdaban2);
    }

    /**
     *
     * @return
     */
    public String getTrasfdaban2SenzaFormattazione() {
        return (trasfdaban2);
    }

    /**
     *
     * @param trasfdaban2
     */
    public void setTrasfdaban2(String trasfdaban2) {
        this.trasfdaban2 = trasfdaban2;
    }

    /**
     *
     * @return
     */
    public ArrayList<RegisterBuyMonthly_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<RegisterBuyMonthly_value> dati) {
        this.dati = dati;
    }

    /**
     *
     * @return
     */
    public String getTipocliente() {
        return tipocliente;
    }

    /**
     *
     * @param tipocliente
     */
    public void setTipocliente(String tipocliente) {
        this.tipocliente = tipocliente;
    }

    /**
     *
     * @return
     */
    public String getValuta() {
        return valuta;
    }

    /**
     *
     * @param valuta
     */
    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    /**
     *
     * @return
     */
    public String getAcqclienti() {
        return (acqclienti);
    }

    /**
     *
     * @param acqclienti
     */
    public void setAcqclienti(String acqclienti) {
        this.acqclienti = acqclienti;
    }

    /**
     *
     * @return
     */
    public String getControvalore() {
        return (controvalore);
    }

    /**
     *
     * @param controvalore
     */
    public void setControvalore(String controvalore) {
        this.controvalore = controvalore;
    }

    /**
     *
     * @return
     */
    public String getControvaloreSenzaFormattazione() {
        return (controvalore);
    }

    /**
     *
     * @return
     */
    public String getSaldovaluta() {
        return (saldovaluta);
    }

    /**
     *
     * @return
     */
    public String getSaldoValutaSenzaFormattazione() {
        return (saldovaluta);
    }

    /**
     *
     * @param saldovaluta
     */
    public void setSaldovaluta(String saldovaluta) {
        this.saldovaluta = saldovaluta;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

}
