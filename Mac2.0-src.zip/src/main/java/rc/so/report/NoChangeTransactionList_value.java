/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class NoChangeTransactionList_value {
    
    
    String id_filiale, de_filiale,dataDa,dataA,till,dateTime,categoryTrans,kindTrans, note, quantity, total,user,inout,annullato ;    
    
    String idop;
    String cod;
    
    //inout=1 -->IN
    //inout=2 -->OUT
    
    //annullato =0 --> 
    //annullato=1 --> è annullato
    
    ArrayList<NoChangeTransactionList_value> dati;

    /**
     *
     * @return
     */
    public String getCod() {
        return cod;
    }

    /**
     *
     * @param cod
     */
    public void setCod(String cod) {
        this.cod = cod;
    }
    
    /**
     *
     * @return
     */
    public String getIdop() {
        return idop;
    }

    /**
     *
     * @param idop
     */
    public void setIdop(String idop) {
        this.idop = idop;
    }
    
    /**
     *
     * @return
     */
    public String getAnnullato() {
        return annullato;
    }

    /**
     *
     * @param annullato
     */
    public void setAnnullato(String annullato) {
        this.annullato = annullato;
    }
    
    /**
     *
     * @return
     */
    public String getInout() {
        return inout;
    }

    /**
     *
     * @param inout
     */
    public void setInout(String inout) {
        this.inout = inout;
    }
    
    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getTill() {
        return till;
    }

    /**
     *
     * @param till
     */
    public void setTill(String till) {
        this.till = till;
    }

    /**
     *
     * @return
     */
    public String getDateTime() {
        return dateTime;
    }

    /**
     *
     * @param dateTime
     */
    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    /**
     *
     * @return
     */
    public String getCategoryTrans() {
        return categoryTrans;
    }

    /**
     *
     * @param categoryTrans
     */
    public void setCategoryTrans(String categoryTrans) {
        this.categoryTrans = categoryTrans;
    }

    /**
     *
     * @return
     */
    public String getKindTrans() {
        return kindTrans;
    }

    /**
     *
     * @param kindTrans
     */
    public void setKindTrans(String kindTrans) {
        this.kindTrans = kindTrans;
    }

    /**
     *
     * @return
     */
    public String getNote() {
        return note;
    }

    /**
     *
     * @param description
     */
    public void setNote(String description) {
        this.note = description;
    }

    /**
     *
     * @return
     */
    public String getQuantity() {
        return quantity;
    }

    /**
     *
     * @param quantity
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /**
     *
     * @return
     */
    public String getTotal() {
        return total;
    }

    /**
     *
     * @param total
     */
    public void setTotal(String total) {
        this.total = total;
    }

    /**
     *
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public ArrayList<NoChangeTransactionList_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<NoChangeTransactionList_value> dati) {
        this.dati = dati;
    }

    
   
}
