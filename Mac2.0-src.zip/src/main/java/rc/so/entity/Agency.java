package rc.so.entity;

/**
 *
 * @author rcosco
 */
public class Agency {
  String id;
  String filiale;
  String agenzia;
  String de_agenzia;
  String indirizzo;
  String cap;
  String citta;
  String telefono;
  String fax;
  String email;
  String fg_annullato;
  
    /**
     *
     * @return
     */
    public String getId() {
    return this.id;
  }
  
    /**
     *
     * @param id
     */
    public void setId(String id) {
    this.id = id;
  }
  
    /**
     *
     * @return
     */
    public String getFiliale() {
    return this.filiale;
  }
  
    /**
     *
     * @param filiale
     */
    public void setFiliale(String filiale) {
    this.filiale = filiale;
  }
  
    /**
     *
     * @return
     */
    public String getAgenzia() {
    return this.agenzia;
  }
  
    /**
     *
     * @param agenzia
     */
    public void setAgenzia(String agenzia) {
    this.agenzia = agenzia;
  }
  
    /**
     *
     * @return
     */
    public String getDe_agenzia() {
    return this.de_agenzia;
  }
  
    /**
     *
     * @param de_agenzia
     */
    public void setDe_agenzia(String de_agenzia) {
    this.de_agenzia = de_agenzia;
  }
  
    /**
     *
     * @return
     */
    public String getIndirizzo() {
    return this.indirizzo;
  }
  
    /**
     *
     * @param indirizzo
     */
    public void setIndirizzo(String indirizzo) {
    this.indirizzo = indirizzo;
  }
  
    /**
     *
     * @return
     */
    public String getCap() {
    return this.cap;
  }
  
    /**
     *
     * @param cap
     */
    public void setCap(String cap) {
    this.cap = cap;
  }
  
    /**
     *
     * @return
     */
    public String getCitta() {
    return this.citta;
  }
  
    /**
     *
     * @param citta
     */
    public void setCitta(String citta) {
    this.citta = citta;
  }
  
    /**
     *
     * @return
     */
    public String getTelefono() {
    return this.telefono;
  }
  
    /**
     *
     * @param telefono
     */
    public void setTelefono(String telefono) {
    this.telefono = telefono;
  }
  
    /**
     *
     * @return
     */
    public String getFax() {
    return this.fax;
  }
  
    /**
     *
     * @param fax
     */
    public void setFax(String fax) {
    this.fax = fax;
  }
  
    /**
     *
     * @return
     */
    public String getEmail() {
    return this.email;
  }
  
    /**
     *
     * @param email
     */
    public void setEmail(String email) {
    this.email = email;
  }
  
    /**
     *
     * @return
     */
    public String getFg_annullato() {
    return this.fg_annullato;
  }
  
    /**
     *
     * @param fg_annullato
     */
    public void setFg_annullato(String fg_annullato) {
    this.fg_annullato = fg_annullato;
  }
}


/* Location:              C:\Users\rcosco\Desktop\classes\!\entity\Agency.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */