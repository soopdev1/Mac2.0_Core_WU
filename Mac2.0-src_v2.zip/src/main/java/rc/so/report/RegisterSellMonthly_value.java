/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class RegisterSellMonthly_value {

    ArrayList<RegisterSellMonthly_value> dati;

    String id_filiale, de_filiale, tipocliente, valuta, venditaclienti, controvalore, saldovaluta, saldo, trasfadip1, trasfadip2, trasfabache1, trasfabacnhe2;

    /**
     *
     * @return
     */
    public ArrayList<RegisterSellMonthly_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<RegisterSellMonthly_value> dati) {
        this.dati = dati;
    }

    /**
     *
     * @return
     */
    public String getTrasfadip1() {
        return (trasfadip1);
    }

    /**
     *
     * @return
     */
    public String getTrasfadip1SenzaFormattazione() {
        return (trasfadip1);
    }

    /**
     *
     * @param trasfadip1
     */
    public void setTrasfadip1(String trasfadip1) {
        this.trasfadip1 = trasfadip1;
    }

    /**
     *
     * @return
     */
    public String getTrasfadip2() {
        return (trasfadip2);
    }

    /**
     *
     * @return
     */
    public String getTrasfadip2SenzaFormattazione() {
        return (trasfadip2);
    }

    /**
     *
     * @param trasfadip2
     */
    public void setTrasfadip2(String trasfadip2) {
        this.trasfadip2 = trasfadip2;
    }

    /**
     *
     * @return
     */
    public String getTrasfabache1() {
        return (trasfabache1);
    }

    /**
     *
     * @return
     */
    public String getTrasfabache1SenzaFormattazione() {
        return (trasfabache1);
    }

    /**
     *
     * @param trasfabache1
     */
    public void setTrasfabache1(String trasfabache1) {
        this.trasfabache1 = trasfabache1;
    }

    /**
     *
     * @return
     */
    public String getTrasfabacnhe2() {
        return (trasfabacnhe2);
    }

    /**
     *
     * @return
     */
    public String getTrasfabacnhe2SenzaFormattazione() {
        return (trasfabacnhe2);
    }

    /**
     *
     * @param trasfabacnhe2
     */
    public void setTrasfabacnhe2(String trasfabacnhe2) {
        this.trasfabacnhe2 = trasfabacnhe2;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getTipocliente() {
        return tipocliente;
    }

    /**
     *
     * @param tipocliente
     */
    public void setTipocliente(String tipocliente) {
        this.tipocliente = tipocliente;
    }

    /**
     *
     * @return
     */
    public String getValuta() {
        return valuta;
    }

    /**
     *
     * @param valuta
     */
    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    /**
     *
     * @return
     */
    public String getVenditaclienti() {
        return (venditaclienti);
    }

    /**
     *
     * @return
     */
    public String getVenditaclientiSenzaFormattazione() {
        return (venditaclienti);
    }

    /**
     *
     * @param venditaclienti
     */
    public void setVenditaclienti(String venditaclienti) {
        this.venditaclienti = venditaclienti;
    }

    /**
     *
     * @return
     */
    public String getControvalore() {
        return (controvalore);
    }

    /**
     *
     * @return
     */
    public String getControvaloreSenzaFormattazione() {
        return (controvalore);
    }

    /**
     *
     * @param controvalore
     */
    public void setControvalore(String controvalore) {
        this.controvalore = controvalore;
    }

    /**
     *
     * @return
     */
    public String getSaldovaluta() {
        return (saldovaluta);
    }

    /**
     *
     * @return
     */
    public String getSaldovalutaSenzaFormattazione() {
        return (saldovaluta);
    }

    /**
     *
     * @param saldovaluta
     */
    public void setSaldovaluta(String saldovaluta) {
        this.saldovaluta = saldovaluta;
    }

    /**
     *
     * @return
     */
    public String getSaldo() {
        return (saldo);
    }

    /**
     *
     * @return
     */
    public String getSaldoSenzaFormattazione() {
        return (saldo);
    }

    /**
     *
     * @param saldo
     */
    public void setSaldo(String saldo) {
        this.saldo = saldo;
    }

}
