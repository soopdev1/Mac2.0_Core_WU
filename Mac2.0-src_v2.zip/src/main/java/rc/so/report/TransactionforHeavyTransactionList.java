/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;



/**
 *
 * @author vcrugliano
 */
public class TransactionforHeavyTransactionList {
    
    
    String date,rs,buysell,b,currency,quantity,amount,currencylocal,sanction,clientpep,moneysource,transactionreason;

    /**
     *
     * @return
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param date
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *
     * @return
     */
    public String getRs() {
        return rs;
    }

    /**
     *
     * @param rs
     */
    public void setRs(String rs) {
        this.rs = rs;
    }

    /**
     *
     * @return
     */
    public String getBuysell() {
        return buysell;
    }

    /**
     *
     * @param buysell
     */
    public void setBuysell(String buysell) {
        this.buysell = buysell;
    }

    /**
     *
     * @return
     */
    public String getB() {
        return b;
    }

    /**
     *
     * @param b
     */
    public void setB(String b) {
        this.b = b;
    }

    /**
     *
     * @return
     */
    public String getQuantity() {
        return (quantity);
    }
    
    /**
     *
     * @return
     */
    public String getQuantitySenzaFormattazione() {
        return quantity;
    }

    /**
     *
     * @param quantity
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /**
     *
     * @return
     */
    public String getAmount() {
        return (amount);
    }
    
    /**
     *
     * @return
     */
    public String getAmountSenzaFormattazione() {
        return amount;
    }

    /**
     *
     * @param amount
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     *
     * @return
     */
    public String getSanction() {
        return sanction;
    }

    /**
     *
     * @param sanction
     */
    public void setSanction(String sanction) {
        this.sanction = sanction;
    }

    /**
     *
     * @return
     */
    public String getClientpep() {
        return clientpep;
    }

    /**
     *
     * @param clientpep
     */
    public void setClientpep(String clientpep) {
        this.clientpep = clientpep;
    }

    /**
     *
     * @return
     */
    public String getMoneysource() {
        return moneysource;
    }

    /**
     *
     * @param moneysource
     */
    public void setMoneysource(String moneysource) {
        this.moneysource = moneysource;
    }

    /**
     *
     * @return
     */
    public String getTransactionreason() {
        return transactionreason;
    }

    /**
     *
     * @param transactionreason
     */
    public void setTransactionreason(String transactionreason) {
        this.transactionreason = transactionreason;
    }

    /**
     *
     * @return
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return
     */
    public String getCurrencylocal() {
        return currencylocal;
    }

    /**
     *
     * @param currencylocal
     */
    public void setCurrencylocal(String currencylocal) {
        this.currencylocal = currencylocal;
    }
    
    
    
}

