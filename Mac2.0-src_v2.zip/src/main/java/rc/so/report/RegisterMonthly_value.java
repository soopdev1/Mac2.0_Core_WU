/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;

import java.util.ArrayList;
/**
 *
 * @author srotella
 */
public class RegisterMonthly_value {
    
    ArrayList<RegisterMonthly_value> dati;   
    
    String id_filiale, de_filiale,tipocliente,valuta,acqdaclienti,venditaaclienti,trasfdadip,trasfadip,trasfdabanche,trasfabanche,controvalore;
    
    /**
     *
     * @return
     */
    public ArrayList<RegisterMonthly_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<RegisterMonthly_value> dati) {
        this.dati = dati;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getTipocliente() {
        return tipocliente;
    }

    /**
     *
     * @param tipocliente
     */
    public void setTipocliente(String tipocliente) {
        this.tipocliente = tipocliente;
    }

    /**
     *
     * @return
     */
    public String getValuta() {
        return valuta;
    }

    /**
     *
     * @param valuta
     */
    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    /**
     *
     * @return
     */
    public String getAcqdaclienti() {
        return (acqdaclienti);
    }
    
    /**
     *
     * @return
     */
    public String getAcqdaclientiSenzaFormattazione() {
        return (acqdaclienti);
    }

    /**
     *
     * @param acqdaclienti
     */
    public void setAcqdaclienti(String acqdaclienti) {
        this.acqdaclienti = acqdaclienti;
    }

    /**
     *
     * @return
     */
    public String getVenditaaclienti() {
        return (venditaaclienti);
    }
    
    /**
     *
     * @return
     */
    public String getVenditaaclientiSenzaFormattazione() {
        return (venditaaclienti);
    }

    /**
     *
     * @param venditaaclienti
     */
    public void setVenditaaclienti(String venditaaclienti) {
        this.venditaaclienti = venditaaclienti;
    }

    /**
     *
     * @return
     */
    public String getTrasfdadip() {
        return (trasfdadip);
    }
    
    /**
     *
     * @return
     */
    public String getTrasfdadipSenzaFormattazione() {
        return (trasfdadip);
    }

    /**
     *
     * @param trasfdadip
     */
    public void setTrasfdadip(String trasfdadip) {
        this.trasfdadip = trasfdadip;
    }

    /**
     *
     * @return
     */
    public String getTrasfadip() {
        return (trasfadip);
    }
    
    /**
     *
     * @return
     */
    public String getTrasfadipSenzaFormattazione() {
        return (trasfadip);
    }

    /**
     *
     * @param trasfadip
     */
    public void setTrasfadip(String trasfadip) {
        this.trasfadip = trasfadip;
    }

    /**
     *
     * @return
     */
    public String getTrasfdabanche() {
        return (trasfdabanche);
    }
    
    /**
     *
     * @return
     */
    public String getTrasfdabancheSenzaFormattazione() {
        return (trasfdabanche);
    }

    /**
     *
     * @param trasfdabanche
     */
    public void setTrasfdabanche(String trasfdabanche) {
        this.trasfdabanche = trasfdabanche;
    }

    /**
     *
     * @return
     */
    public String getTrasfabanche() {
        return (trasfabanche);
    }
    
    /**
     *
     * @return
     */
    public String getTrasfabancheSenzaFormattazione() {
        return (trasfabanche);
    }

    /**
     *
     * @param trasfabanche
     */
    public void setTrasfabanche(String trasfabanche) {
        this.trasfabanche = trasfabanche;
    }

    /**
     *
     * @return
     */
    public String getControvalore() {
        return (controvalore);
    }
    
    /**
     *
     * @return
     */
    public String getControvaloreSenzaFormattazione() {
        return controvalore;
    }

    /**
     *
     * @param controvalore
     */
    public void setControvalore(String controvalore) {
        this.controvalore = controvalore;
    }
    
}
