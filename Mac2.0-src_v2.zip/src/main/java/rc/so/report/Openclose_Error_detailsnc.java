/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;

/**
 *
 * @author rcosco
 */
public class Openclose_Error_detailsnc {
    String category,quantityUser,quantitySystem,diff,note,amount;

    /**
     *
     * @return
     */
    public String getAmount() {
        return amount;
    }

    /**
     *
     * @param amount
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     *
     * @return
     */
    public String getCategory() {
        return category;
    }

    /**
     *
     * @param category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     *
     * @return
     */
    public String getQuantityUser() {
        return quantityUser;
    }

    /**
     *
     * @param quantityUser
     */
    public void setQuantityUser(String quantityUser) {
        this.quantityUser = quantityUser;
    }

    /**
     *
     * @return
     */
    public String getQuantitySystem() {
        return quantitySystem;
    }

    /**
     *
     * @param quantitySystem
     */
    public void setQuantitySystem(String quantitySystem) {
        this.quantitySystem = quantitySystem;
    }

    /**
     *
     * @return
     */
    public String getDiff() {
        return diff;
    }

    /**
     *
     * @param diff
     */
    public void setDiff(String diff) {
        this.diff = diff;
    }

    /**
     *
     * @return
     */
    public String getNote() {
        return note;
    }

    /**
     *
     * @param note
     */
    public void setNote(String note) {
        this.note = note;
    }
}
