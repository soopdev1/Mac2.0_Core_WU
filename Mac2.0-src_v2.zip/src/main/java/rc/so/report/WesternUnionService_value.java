/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class WesternUnionService_value {
    
    
    String id_filiale, de_filiale,dataDa,dataA,till,dateTime,noControl,noInvoice, netInOutSend, netInOutReceive, send, receive, CoomWUSend, user,inout,annullato ;    
    
    ArrayList<WesternUnionService_value> dati;

    /**
     *
     * @return
     */
    public String getInout() {
        return inout;
    }

    /**
     *
     * @param inout
     */
    public void setInout(String inout) {
        this.inout = inout;
    }

    /**
     *
     * @return
     */
    public String getAnnullato() {
        return annullato;
    }

    /**
     *
     * @param annullato
     */
    public void setAnnullato(String annullato) {
        this.annullato = annullato;
    }
    
    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @return
     */
    public String getNetInOutSend() {
        return netInOutSend;
    }

    /**
     *
     * @param netInOutSend
     */
    public void setNetInOutSend(String netInOutSend) {
        this.netInOutSend = netInOutSend;
    }

    /**
     *
     * @return
     */
    public String getNetInOutReceive() {
        return netInOutReceive;
    }

    /**
     *
     * @param netInOutReceive
     */
    public void setNetInOutReceive(String netInOutReceive) {
        this.netInOutReceive = netInOutReceive;
    }

    /**
     *
     * @return
     */
    public String getNoControl() {
        return noControl;
    }

    /**
     *
     * @param noControl
     */
    public void setNoControl(String noControl) {
        this.noControl = noControl;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getTill() {
        return till;
    }

    /**
     *
     * @param till
     */
    public void setTill(String till) {
        this.till = till;
    }

    /**
     *
     * @return
     */
    public String getDateTime() {
        return dateTime;
    }

    /**
     *
     * @param dateTime
     */
    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    /**
     *
     * @return
     */
    public String getNoInvoice() {
        return noInvoice;
    }

    /**
     *
     * @param noInvoice
     */
    public void setNoInvoice(String noInvoice) {
        this.noInvoice = noInvoice;
    }

    /**
     *
     * @return
     */
    public String getSend() {
        return send;
    }

    /**
     *
     * @param send
     */
    public void setSend(String send) {
        this.send = send;
    }

    /**
     *
     * @return
     */
    public String getReceive() {
        return receive;
    }

    /**
     *
     * @param receive
     */
    public void setReceive(String receive) {
        this.receive = receive;
    }

    /**
     *
     * @return
     */
    public String getCoomWUSend() {
        return CoomWUSend;
    }

    /**
     *
     * @param CoomWUSend
     */
    public void setCoomWUSend(String CoomWUSend) {
        this.CoomWUSend = CoomWUSend;
    }

    /**
     *
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public ArrayList<WesternUnionService_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<WesternUnionService_value> dati) {
        this.dati = dati;
    }

  
}
