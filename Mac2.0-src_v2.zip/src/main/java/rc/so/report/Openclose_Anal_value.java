/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.report;

import java.util.ArrayList;

/**
 *
 * @author rcosco
 */
public class Openclose_Anal_value {
     String id_filiale, de_filiale,operazione,tipo,data,user,dasafetill,numerrori,valuta,suppporto,numsupporti,importo;
    
    ArrayList<Openclose_Anal_value> dati;

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getOperazione() {
        return operazione;
    }

    /**
     *
     * @param operazione
     */
    public void setOperazione(String operazione) {
        this.operazione = operazione;
    }

    /**
     *
     * @return
     */
    public String getTipo() {
        return tipo;
    }

    /**
     *
     * @param tipo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     *
     * @return
     */
    public String getData() {
        return data;
    }

    /**
     *
     * @param data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     *
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public String getSafetill() {
        return dasafetill;
    }

    /**
     *
     * @param dasafetill
     */
    public void setSafetill(String dasafetill) {
        this.dasafetill = dasafetill;
    }

    /**
     *
     * @return
     */
    public String getNumerrori() {
        return numerrori;
    }

    /**
     *
     * @param numerrori
     */
    public void setNumerrori(String numerrori) {
        this.numerrori = numerrori;
    }

    /**
     *
     * @return
     */
    public String getValuta() {
        return valuta;
    }

    /**
     *
     * @param valuta
     */
    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    /**
     *
     * @return
     */
    public String getSuppporto() {
        return suppporto;
    }

    /**
     *
     * @param suppporto
     */
    public void setSuppporto(String suppporto) {
        this.suppporto = suppporto;
    }

    /**
     *
     * @return
     */
    public String getNumsupporti() {
        return numsupporti;
    }

    /**
     *
     * @param numsupporti
     */
    public void setNumsupporti(String numsupporti) {
        this.numsupporti = numsupporti;
    }

    /**
     *
     * @return
     */
    public String getImporto() {
        return importo;
    }

    /**
     *
     * @param importo
     */
    public void setImporto(String importo) {
        this.importo = importo;
    }

    /**
     *
     * @return
     */
    public ArrayList<Openclose_Anal_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<Openclose_Anal_value> dati) {
        this.dati = dati;
    }
}
