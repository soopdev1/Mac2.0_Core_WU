/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.entity;

/**
 *
 * @author rcosco
 */
public class Ticket {

    String resultCode, resultDesc;
    String idTranPaymat;

    String logoAziendale, nomeEsercente, descrizioneProdotto, dataOraTransazione, esitoTransazione, logoBrand, importoFacciale, noteTransazione,
            linkSitoWeb, numeroAssistenza, footerScontrino, idTerminale, ABI, CAB, numero_operazione, id_autorizzazione, idTranPaymat_ticket, numeroTelefonico;

    /**
     *
     * @return
     */
    public String getResultCode() {
        return resultCode;
    }

    /**
     *
     * @param resultCode
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    /**
     *
     * @return
     */
    public String getResultDesc() {
        return resultDesc;
    }

    /**
     *
     * @param resultDesc
     */
    public void setResultDesc(String resultDesc) {
        this.resultDesc = resultDesc;
    }

    /**
     *
     * @return
     */
    public String getIdTranPaymat() {
        return idTranPaymat;
    }

    /**
     *
     * @param idTranPaymat
     */
    public void setIdTranPaymat(String idTranPaymat) {
        this.idTranPaymat = idTranPaymat;
    }

    /**
     *
     * @return
     */
    public String getLogoAziendale() {
        return logoAziendale;
    }

    /**
     *
     * @param logoAziendale
     */
    public void setLogoAziendale(String logoAziendale) {
        this.logoAziendale = logoAziendale;
    }

    /**
     *
     * @return
     */
    public String getNomeEsercente() {
        return nomeEsercente;
    }

    /**
     *
     * @param nomeEsercente
     */
    public void setNomeEsercente(String nomeEsercente) {
        this.nomeEsercente = nomeEsercente;
    }

    /**
     *
     * @return
     */
    public String getDescrizioneProdotto() {
        return descrizioneProdotto;
    }

    /**
     *
     * @param descrizioneProdotto
     */
    public void setDescrizioneProdotto(String descrizioneProdotto) {
        this.descrizioneProdotto = descrizioneProdotto;
    }

    /**
     *
     * @return
     */
    public String getDataOraTransazione() {
        return dataOraTransazione;
    }

    /**
     *
     * @param dataOraTransazione
     */
    public void setDataOraTransazione(String dataOraTransazione) {
        this.dataOraTransazione = dataOraTransazione;
    }

    /**
     *
     * @return
     */
    public String getEsitoTransazione() {
        return esitoTransazione;
    }

    /**
     *
     * @param esitoTransazione
     */
    public void setEsitoTransazione(String esitoTransazione) {
        this.esitoTransazione = esitoTransazione;
    }

    /**
     *
     * @return
     */
    public String getLogoBrand() {
        return logoBrand;
    }

    /**
     *
     * @param logoBrand
     */
    public void setLogoBrand(String logoBrand) {
        this.logoBrand = logoBrand;
    }

    /**
     *
     * @return
     */
    public String getImportoFacciale() {
        return importoFacciale;
    }

    /**
     *
     * @param importoFacciale
     */
    public void setImportoFacciale(String importoFacciale) {
        this.importoFacciale = importoFacciale;
    }

    /**
     *
     * @return
     */
    public String getNoteTransazione() {
        return noteTransazione;
    }

    /**
     *
     * @param noteTransazione
     */
    public void setNoteTransazione(String noteTransazione) {
        this.noteTransazione = noteTransazione;
    }

    /**
     *
     * @return
     */
    public String getLinkSitoWeb() {
        return linkSitoWeb;
    }

    /**
     *
     * @param linkSitoWeb
     */
    public void setLinkSitoWeb(String linkSitoWeb) {
        this.linkSitoWeb = linkSitoWeb;
    }

    /**
     *
     * @return
     */
    public String getNumeroAssistenza() {
        return numeroAssistenza;
    }

    /**
     *
     * @param numeroAssistenza
     */
    public void setNumeroAssistenza(String numeroAssistenza) {
        this.numeroAssistenza = numeroAssistenza;
    }

    /**
     *
     * @return
     */
    public String getFooterScontrino() {
        return footerScontrino;
    }

    /**
     *
     * @param footerScontrino
     */
    public void setFooterScontrino(String footerScontrino) {
        this.footerScontrino = footerScontrino;
    }

    /**
     *
     * @return
     */
    public String getIdTerminale() {
        return idTerminale;
    }

    /**
     *
     * @param idTerminale
     */
    public void setIdTerminale(String idTerminale) {
        this.idTerminale = idTerminale;
    }

    /**
     *
     * @return
     */
    public String getABI() {
        return ABI;
    }

    /**
     *
     * @param ABI
     */
    public void setABI(String ABI) {
        this.ABI = ABI;
    }

    /**
     *
     * @return
     */
    public String getCAB() {
        return CAB;
    }

    /**
     *
     * @param CAB
     */
    public void setCAB(String CAB) {
        this.CAB = CAB;
    }

    /**
     *
     * @return
     */
    public String getNumero_operazione() {
        return numero_operazione;
    }

    /**
     *
     * @param numero_operazione
     */
    public void setNumero_operazione(String numero_operazione) {
        this.numero_operazione = numero_operazione;
    }

    /**
     *
     * @return
     */
    public String getId_autorizzazione() {
        return id_autorizzazione;
    }

    /**
     *
     * @param id_autorizzazione
     */
    public void setId_autorizzazione(String id_autorizzazione) {
        this.id_autorizzazione = id_autorizzazione;
    }

    /**
     *
     * @return
     */
    public String getIdTranPaymat_ticket() {
        return idTranPaymat_ticket;
    }

    /**
     *
     * @param idTranPaymat_ticket
     */
    public void setIdTranPaymat_ticket(String idTranPaymat_ticket) {
        this.idTranPaymat_ticket = idTranPaymat_ticket;
    }

    /**
     *
     * @return
     */
    public String getNumeroTelefonico() {
        return numeroTelefonico;
    }

    /**
     *
     * @param numeroTelefonico
     */
    public void setNumeroTelefonico(String numeroTelefonico) {
        this.numeroTelefonico = numeroTelefonico;
    }

    
    
}
