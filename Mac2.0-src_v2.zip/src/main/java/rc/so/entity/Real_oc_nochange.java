/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.entity;

/**
 *
 * @author rcosco
 */
public class Real_oc_nochange {

    String filiale, cod_oc, gruppo_nc, quantity, data;

    /**
     *
     * @return
     */
    public String getFiliale() {
        return filiale;
    }

    /**
     *
     * @param filiale
     */
    public void setFiliale(String filiale) {
        this.filiale = filiale;
    }

    /**
     *
     * @return
     */
    public String getCod_oc() {
        return cod_oc;
    }

    /**
     *
     * @param cod_oc
     */
    public void setCod_oc(String cod_oc) {
        this.cod_oc = cod_oc;
    }

    /**
     *
     * @return
     */
    public String getGruppo_nc() {
        return gruppo_nc;
    }

    /**
     *
     * @param gruppo_nc
     */
    public void setGruppo_nc(String gruppo_nc) {
        this.gruppo_nc = gruppo_nc;
    }

    /**
     *
     * @return
     */
    public String getQuantity() {
        return quantity;
    }

    /**
     *
     * @param quantity
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /**
     *
     * @return
     */
    public String getData() {
        return data;
    }

    /**
     *
     * @param data
     */
    public void setData(String data) {
        this.data = data;
    }
    

    
    
}
