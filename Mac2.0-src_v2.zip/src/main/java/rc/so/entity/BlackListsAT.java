package rc.so.entity;

/**
 *
 * @author rcosco
 */
public class BlackListsAT {

    String nomefile;
    String CodiceTransazione;
    String DataTransazione;
    String Esito;
    String Soggetto;
    String error;
    String transaction_code;

    /**
     *
     * @return
     */
    public String getTransaction_code() {
        return this.transaction_code;
    }

    /**
     *
     * @param transaction_code
     */
    public void setTransaction_code(String transaction_code) {
        this.transaction_code = transaction_code;
    }

    /**
     *
     * @return
     */
    public String getError() {
        return this.error;
    }

    /**
     *
     * @param error
     */
    public void setError(String error) {
        this.error = error;
    }

    /**
     *
     * @return
     */
    public String getNomefile() {
        return this.nomefile;
    }

    /**
     *
     * @param nomefile
     */
    public void setNomefile(String nomefile) {
        this.nomefile = nomefile;
    }

    /**
     *
     * @return
     */
    public String getCodiceTransazione() {
        return this.CodiceTransazione;
    }

    /**
     *
     * @param CodiceTransazione
     */
    public void setCodiceTransazione(String CodiceTransazione) {
        this.CodiceTransazione = CodiceTransazione;
    }

    /**
     *
     * @return
     */
    public String getDataTransazione() {
        return this.DataTransazione;
    }

    /**
     *
     * @param DataTransazione
     */
    public void setDataTransazione(String DataTransazione) {
        this.DataTransazione = DataTransazione;
    }

    /**
     *
     * @return
     */
    public String getEsito() {
        return this.Esito;
    }

    /**
     *
     * @param Esito
     */
    public void setEsito(String Esito) {
        this.Esito = Esito;
    }

    /**
     *
     * @return
     */
    public String getSoggetto() {
        return this.Soggetto;
    }

    /**
     *
     * @param Soggetto
     */
    public void setSoggetto(String Soggetto) {
        this.Soggetto = Soggetto;
    }
}


/* Location:              C:\Users\rcosco\Desktop\classes\!\entity\BlackListsAT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
