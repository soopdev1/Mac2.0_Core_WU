/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.entity;

/**
 *
 * @author rcosco
 */
public class Scontrino_Pa {
    
    String title,cat,data,text1,text2,text3,text4,text5,text6,text7,note,l1,l2,l3;

    /**
     * Constructor
     */
    public Scontrino_Pa() {
    }
    
    /**
     *
     * @param title
     * @param cat
     * @param data
     * @param text1
     * @param text2
     * @param text3
     * @param text4
     * @param text5
     * @param text6
     * @param text7
     * @param note
     * @param l1
     * @param l2
     * @param l3
     */
    public Scontrino_Pa(String title, String cat, String data, String text1, String text2, String text3, String text4, String text5, String text6, String text7, String note, String l1, String l2, String l3) {
        this.title = title;
        this.cat = cat;
        this.data = data;
        this.text1 = text1;
        this.text2 = text2;
        this.text3 = text3;
        this.text4 = text4;
        this.text5 = text5;
        this.text6 = text6;
        this.text7 = text7;
        this.note = note;
        this.l1 = l1;
        this.l2 = l2;
        this.l3 = l3;
    }
    
    /**
     *
     * @return
     */
    public String getTitle() {
        return title;
    }

    /**
     *
     * @param title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     *
     * @return
     */
    public String getCat() {
        return cat;
    }

    /**
     *
     * @param cat
     */
    public void setCat(String cat) {
        this.cat = cat;
    }

    /**
     *
     * @return
     */
    public String getData() {
        return data;
    }

    /**
     *
     * @param data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     *
     * @return
     */
    public String getText1() {
        return text1;
    }

    /**
     *
     * @param text1
     */
    public void setText1(String text1) {
        this.text1 = text1;
    }

    /**
     *
     * @return
     */
    public String getText2() {
        return text2;
    }

    /**
     *
     * @param text2
     */
    public void setText2(String text2) {
        this.text2 = text2;
    }

    /**
     *
     * @return
     */
    public String getText3() {
        return text3;
    }

    /**
     *
     * @param text3
     */
    public void setText3(String text3) {
        this.text3 = text3;
    }

    /**
     *
     * @return
     */
    public String getText4() {
        return text4;
    }

    /**
     *
     * @param text4
     */
    public void setText4(String text4) {
        this.text4 = text4;
    }

    /**
     *
     * @return
     */
    public String getText5() {
        return text5;
    }

    /**
     *
     * @param text5
     */
    public void setText5(String text5) {
        this.text5 = text5;
    }

    /**
     *
     * @return
     */
    public String getText6() {
        return text6;
    }

    /**
     *
     * @param text6
     */
    public void setText6(String text6) {
        this.text6 = text6;
    }

    /**
     *
     * @return
     */
    public String getText7() {
        return text7;
    }

    /**
     *
     * @param text7
     */
    public void setText7(String text7) {
        this.text7 = text7;
    }

    /**
     *
     * @return
     */
    public String getNote() {
        return note;
    }

    /**
     *
     * @param note
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     *
     * @return
     */
    public String getL1() {
        return l1;
    }

    /**
     *
     * @param l1
     */
    public void setL1(String l1) {
        this.l1 = l1;
    }

    /**
     *
     * @return
     */
    public String getL2() {
        return l2;
    }

    /**
     *
     * @param l2
     */
    public void setL2(String l2) {
        this.l2 = l2;
    }

    /**
     *
     * @return
     */
    public String getL3() {
        return l3;
    }

    /**
     *
     * @param l3
     */
    public void setL3(String l3) {
        this.l3 = l3;
    }
    
    
    
}
