package rc.so.entity;

/**
 *
 * @author rcosco
 */
public class Firma
{
  String codicesott;
  
  String doc_id;
  
  String wor_id;
  String stato_ini;
  String stato_fin;
  String user;
  String path;
  String data;
  String nomefile;
  
    /**
     *
     * @return
     */
    public String getCodicesott()
  {
    return this.codicesott;
  }
  
    /**
     *
     * @param codicesott
     */
    public void setCodicesott(String codicesott) {
    this.codicesott = codicesott;
  }
  
    /**
     *
     * @return
     */
    public String getDoc_id() {
    return this.doc_id;
  }
  
    /**
     *
     * @param doc_id
     */
    public void setDoc_id(String doc_id) {
    this.doc_id = doc_id;
  }
  
    /**
     *
     * @return
     */
    public String getWor_id() {
    return this.wor_id;
  }
  
    /**
     *
     * @param wor_id
     */
    public void setWor_id(String wor_id) {
    this.wor_id = wor_id;
  }
  
    /**
     *
     * @return
     */
    public String getStato_ini() {
    return this.stato_ini;
  }
  
    /**
     *
     * @param stato_ini
     */
    public void setStato_ini(String stato_ini) {
    this.stato_ini = stato_ini;
  }
  
    /**
     *
     * @return
     */
    public String getStato_fin() {
    return this.stato_fin;
  }
  
    /**
     *
     * @param stato_fin
     */
    public void setStato_fin(String stato_fin) {
    this.stato_fin = stato_fin;
  }
  
    /**
     *
     * @return
     */
    public String getUser() {
    return this.user;
  }
  
    /**
     *
     * @param user
     */
    public void setUser(String user) {
    this.user = user;
  }
  
    /**
     *
     * @return
     */
    public String getPath() {
    return this.path;
  }
  
    /**
     *
     * @param path
     */
    public void setPath(String path) {
    this.path = path;
  }
  
    /**
     *
     * @return
     */
    public String getData() {
    return this.data;
  }
  
    /**
     *
     * @param data
     */
    public void setData(String data) {
    this.data = data;
  }
  
    /**
     *
     * @return
     */
    public String getNomefile() {
    return this.nomefile;
  }
  
    /**
     *
     * @param nomefile
     */
    public void setNomefile(String nomefile) {
    this.nomefile = nomefile;
  }
}


/* Location:              C:\Users\rcosco\Desktop\classes\!\entity\Firma.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */