/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.excel;

/**
 *
 * @author rcosco
 */
public class DailyChange_CG {
    
    String CDC,SPORTELLO,ID,DELETE,AREA,CITTA,UBICAZIONE,GRUPPO;
    String DATA,ORA,MESE,ANNO,CODUSER,USERNOME,USERCOGNOME;
    String METODOPAGAMENTO;
    String RESIDENZACLIENTE,NAZIONALITACLIENTE,COMMENTI,ACQUISTOVENDITA,TIPOLOGIAACQOVEND,VALUTA,QUANTITA,TASSODICAMBIO,CONTROVALORE,COMMVARIABILE,COMMFISSA;
    String SPREADBRANCH,SPREADBANK,SPREADVEND;
    String TOTGM,PERCCOMM,PERCSPREADVENDITA,VENDITABUYBACK,VENDITASELLBACK,CODICEINTERNETBOOKING;
    String MOTIVOPERRIDUZIONEDELLACOMM,MOTIVOPERRIDUZIONEDELLACOMMFISSA;
    String CODICESBLOCCO;
    String LOYALTYCODE;

    /**
     *
     * @return
     */
    public String getLOYALTYCODE() {
        return LOYALTYCODE;
    }

    /**
     *
     * @param LOYALTYCODE
     */
    public void setLOYALTYCODE(String LOYALTYCODE) {
        this.LOYALTYCODE = LOYALTYCODE;
    }
    
    /**
     *
     * @return
     */
    public String getCDC() {
        return CDC;
    }

    /**
     *
     * @param CDC
     */
    public void setCDC(String CDC) {
        this.CDC = CDC;
    }

    /**
     *
     * @return
     */
    public String getSPORTELLO() {
        return SPORTELLO;
    }

    /**
     *
     * @param SPORTELLO
     */
    public void setSPORTELLO(String SPORTELLO) {
        this.SPORTELLO = SPORTELLO;
    }

    /**
     *
     * @return
     */
    public String getID() {
        return ID;
    }

    /**
     *
     * @param ID
     */
    public void setID(String ID) {
        this.ID = ID;
    }

    /**
     *
     * @return
     */
    public String getDELETE() {
        return DELETE;
    }

    /**
     *
     * @param DELETE
     */
    public void setDELETE(String DELETE) {
        this.DELETE = DELETE;
    }

    /**
     *
     * @return
     */
    public String getAREA() {
        return AREA;
    }

    /**
     *
     * @param AREA
     */
    public void setAREA(String AREA) {
        this.AREA = AREA;
    }

    /**
     *
     * @return
     */
    public String getCITTA() {
        return CITTA;
    }

    /**
     *
     * @param CITTA
     */
    public void setCITTA(String CITTA) {
        this.CITTA = CITTA;
    }

    /**
     *
     * @return
     */
    public String getUBICAZIONE() {
        return UBICAZIONE;
    }

    /**
     *
     * @param UBICAZIONE
     */
    public void setUBICAZIONE(String UBICAZIONE) {
        this.UBICAZIONE = UBICAZIONE;
    }

    /**
     *
     * @return
     */
    public String getGRUPPO() {
        return GRUPPO;
    }

    /**
     *
     * @param GRUPPO
     */
    public void setGRUPPO(String GRUPPO) {
        this.GRUPPO = GRUPPO;
    }

    /**
     *
     * @return
     */
    public String getDATA() {
        return DATA;
    }

    /**
     *
     * @param DATA
     */
    public void setDATA(String DATA) {
        this.DATA = DATA;
    }

    /**
     *
     * @return
     */
    public String getORA() {
        return ORA;
    }

    /**
     *
     * @param ORA
     */
    public void setORA(String ORA) {
        this.ORA = ORA;
    }

    /**
     *
     * @return
     */
    public String getMESE() {
        return MESE;
    }

    /**
     *
     * @param MESE
     */
    public void setMESE(String MESE) {
        this.MESE = MESE;
    }

    /**
     *
     * @return
     */
    public String getANNO() {
        return ANNO;
    }

    /**
     *
     * @param ANNO
     */
    public void setANNO(String ANNO) {
        this.ANNO = ANNO;
    }

    /**
     *
     * @return
     */
    public String getCODUSER() {
        return CODUSER;
    }

    /**
     *
     * @param CODUSER
     */
    public void setCODUSER(String CODUSER) {
        this.CODUSER = CODUSER;
    }

    /**
     *
     * @return
     */
    public String getUSERNOME() {
        return USERNOME;
    }

    /**
     *
     * @param USERNOME
     */
    public void setUSERNOME(String USERNOME) {
        this.USERNOME = USERNOME;
    }

    /**
     *
     * @return
     */
    public String getUSERCOGNOME() {
        return USERCOGNOME;
    }

    /**
     *
     * @param USERCOGNOME
     */
    public void setUSERCOGNOME(String USERCOGNOME) {
        this.USERCOGNOME = USERCOGNOME;
    }

    /**
     *
     * @return
     */
    public String getMETODOPAGAMENTO() {
        return METODOPAGAMENTO;
    }

    /**
     *
     * @param METODOPAGAMENTO
     */
    public void setMETODOPAGAMENTO(String METODOPAGAMENTO) {
        this.METODOPAGAMENTO = METODOPAGAMENTO;
    }

    /**
     *
     * @return
     */
    public String getRESIDENZACLIENTE() {
        return RESIDENZACLIENTE;
    }

    /**
     *
     * @param RESIDENZACLIENTE
     */
    public void setRESIDENZACLIENTE(String RESIDENZACLIENTE) {
        this.RESIDENZACLIENTE = RESIDENZACLIENTE;
    }

    /**
     *
     * @return
     */
    public String getNAZIONALITACLIENTE() {
        return NAZIONALITACLIENTE;
    }

    /**
     *
     * @param NAZIONALITACLIENTE
     */
    public void setNAZIONALITACLIENTE(String NAZIONALITACLIENTE) {
        this.NAZIONALITACLIENTE = NAZIONALITACLIENTE;
    }

    /**
     *
     * @return
     */
    public String getCOMMENTI() {
        return COMMENTI;
    }

    /**
     *
     * @param COMMENTI
     */
    public void setCOMMENTI(String COMMENTI) {
        this.COMMENTI = COMMENTI;
    }

    /**
     *
     * @return
     */
    public String getACQUISTOVENDITA() {
        return ACQUISTOVENDITA;
    }

    /**
     *
     * @param ACQUISTOVENDITA
     */
    public void setACQUISTOVENDITA(String ACQUISTOVENDITA) {
        this.ACQUISTOVENDITA = ACQUISTOVENDITA;
    }

    /**
     *
     * @return
     */
    public String getTIPOLOGIAACQOVEND() {
        return TIPOLOGIAACQOVEND;
    }

    /**
     *
     * @param TIPOLOGIAACQOVEND
     */
    public void setTIPOLOGIAACQOVEND(String TIPOLOGIAACQOVEND) {
        this.TIPOLOGIAACQOVEND = TIPOLOGIAACQOVEND;
    }

    /**
     *
     * @return
     */
    public String getVALUTA() {
        return VALUTA;
    }

    /**
     *
     * @param VALUTA
     */
    public void setVALUTA(String VALUTA) {
        this.VALUTA = VALUTA;
    }

    /**
     *
     * @return
     */
    public String getQUANTITA() {
        return QUANTITA;
    }

    /**
     *
     * @param QUANTITA
     */
    public void setQUANTITA(String QUANTITA) {
        this.QUANTITA = QUANTITA;
    }

    /**
     *
     * @return
     */
    public String getTASSODICAMBIO() {
        return TASSODICAMBIO;
    }

    /**
     *
     * @param TASSODICAMBIO
     */
    public void setTASSODICAMBIO(String TASSODICAMBIO) {
        this.TASSODICAMBIO = TASSODICAMBIO;
    }

    /**
     *
     * @return
     */
    public String getCONTROVALORE() {
        return CONTROVALORE;
    }

    /**
     *
     * @param CONTROVALORE
     */
    public void setCONTROVALORE(String CONTROVALORE) {
        this.CONTROVALORE = CONTROVALORE;
    }

    /**
     *
     * @return
     */
    public String getCOMMVARIABILE() {
        return COMMVARIABILE;
    }

    /**
     *
     * @param COMMVARIABILE
     */
    public void setCOMMVARIABILE(String COMMVARIABILE) {
        this.COMMVARIABILE = COMMVARIABILE;
    }

    /**
     *
     * @return
     */
    public String getCOMMFISSA() {
        return COMMFISSA;
    }

    /**
     *
     * @param COMMFISSA
     */
    public void setCOMMFISSA(String COMMFISSA) {
        this.COMMFISSA = COMMFISSA;
    }

    /**
     *
     * @return
     */
    public String getSPREADBRANCH() {
        return SPREADBRANCH;
    }

    /**
     *
     * @param SPREADBRANCH
     */
    public void setSPREADBRANCH(String SPREADBRANCH) {
        this.SPREADBRANCH = SPREADBRANCH;
    }

    /**
     *
     * @return
     */
    public String getSPREADBANK() {
        return SPREADBANK;
    }

    /**
     *
     * @param SPREADBANK
     */
    public void setSPREADBANK(String SPREADBANK) {
        this.SPREADBANK = SPREADBANK;
    }

    /**
     *
     * @return
     */
    public String getSPREADVEND() {
        return SPREADVEND;
    }

    /**
     *
     * @param SPREADVEND
     */
    public void setSPREADVEND(String SPREADVEND) {
        this.SPREADVEND = SPREADVEND;
    }

    /**
     *
     * @return
     */
    public String getTOTGM() {
        return TOTGM;
    }

    /**
     *
     * @param TOTGM
     */
    public void setTOTGM(String TOTGM) {
        this.TOTGM = TOTGM;
    }

    /**
     *
     * @return
     */
    public String getPERCCOMM() {
        return PERCCOMM;
    }

    /**
     *
     * @param PERCCOMM
     */
    public void setPERCCOMM(String PERCCOMM) {
        this.PERCCOMM = PERCCOMM;
    }

    /**
     *
     * @return
     */
    public String getPERCSPREADVENDITA() {
        return PERCSPREADVENDITA;
    }

    /**
     *
     * @param PERCSPREADVENDITA
     */
    public void setPERCSPREADVENDITA(String PERCSPREADVENDITA) {
        this.PERCSPREADVENDITA = PERCSPREADVENDITA;
    }

    /**
     *
     * @return
     */
    public String getVENDITABUYBACK() {
        return VENDITABUYBACK;
    }

    /**
     *
     * @param VENDITABUYBACK
     */
    public void setVENDITABUYBACK(String VENDITABUYBACK) {
        this.VENDITABUYBACK = VENDITABUYBACK;
    }

    /**
     *
     * @return
     */
    public String getCODICEINTERNETBOOKING() {
        return CODICEINTERNETBOOKING;
    }

    /**
     *
     * @param CODICEINTERNETBOOKING
     */
    public void setCODICEINTERNETBOOKING(String CODICEINTERNETBOOKING) {
        this.CODICEINTERNETBOOKING = CODICEINTERNETBOOKING;
    }

    /**
     *
     * @return
     */
    public String getVENDITASELLBACK() {
        return VENDITASELLBACK;
    }

    /**
     *
     * @param VENDITASELLBACK
     */
    public void setVENDITASELLBACK(String VENDITASELLBACK) {    
        this.VENDITASELLBACK = VENDITASELLBACK;
    }

    /**
     *
     * @return
     */
    public String getMOTIVOPERRIDUZIONEDELLACOMM() {
        return MOTIVOPERRIDUZIONEDELLACOMM;
    }

    /**
     *
     * @param MOTIVOPERRIDUZIONEDELLACOMM
     */
    public void setMOTIVOPERRIDUZIONEDELLACOMM(String MOTIVOPERRIDUZIONEDELLACOMM) {
        this.MOTIVOPERRIDUZIONEDELLACOMM = MOTIVOPERRIDUZIONEDELLACOMM;
    }

    /**
     *
     * @return
     */
    public String getMOTIVOPERRIDUZIONEDELLACOMMFISSA() {
        return MOTIVOPERRIDUZIONEDELLACOMMFISSA;
    }

    /**
     *
     * @param MOTIVOPERRIDUZIONEDELLACOMMFISSA
     */
    public void setMOTIVOPERRIDUZIONEDELLACOMMFISSA(String MOTIVOPERRIDUZIONEDELLACOMMFISSA) {
        this.MOTIVOPERRIDUZIONEDELLACOMMFISSA = MOTIVOPERRIDUZIONEDELLACOMMFISSA;
    }

    /**
     *
     * @return
     */
    public String getCODICESBLOCCO() {
        return CODICESBLOCCO;
    }

    /**
     *
     * @param CODICESBLOCCO
     */
    public void setCODICESBLOCCO(String CODICESBLOCCO) {
        this.CODICESBLOCCO = CODICESBLOCCO;
    }
    

    
    
    
}
