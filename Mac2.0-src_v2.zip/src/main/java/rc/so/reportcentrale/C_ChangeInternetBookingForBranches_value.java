/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class C_ChangeInternetBookingForBranches_value {
    
    String id_filiale, de_filiale,dataDa,dataA;

    String transaction, date, user, currency, support, qty, totalCurrency, percCom, totalCom, totalNet, totalBuy, totalSpread, totalComFix, kindClient, code, description;
    String nTrans;
    
    ArrayList<C_ChangeInternetBookingForBranches_value> dati;

    /**
     *
     * @return
     */
    public String getnTrans() {
        return nTrans;
    }

    /**
     *
     * @param nTrans
     */
    public void setnTrans(String nTrans) {
        this.nTrans = nTrans;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getTransaction() {
        return transaction;
    }

    /**
     *
     * @param transaction
     */
    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    /**
     *
     * @return
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param date
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return
     */
    public String getSupport() {
        return support;
    }

    /**
     *
     * @param support
     */
    public void setSupport(String support) {
        this.support = support;
    }

    /**
     *
     * @return
     */
    public String getQty() {
        return qty;
    }

    /**
     *
     * @param qty
     */
    public void setQty(String qty) {
        this.qty = qty;
    }

    /**
     *
     * @return
     */
    public String getTotalCurrency() {
        return totalCurrency;
    }

    /**
     *
     * @param totalCurrency
     */
    public void setTotalCurrency(String totalCurrency) {
        this.totalCurrency = totalCurrency;
    }

    /**
     *
     * @return
     */
    public String getPercCom() {
        return percCom;
    }

    /**
     *
     * @param percCom
     */
    public void setPercCom(String percCom) {
        this.percCom = percCom;
    }

    /**
     *
     * @return
     */
    public String getTotalCom() {
        return totalCom;
    }

    /**
     *
     * @param totalCom
     */
    public void setTotalCom(String totalCom) {
        this.totalCom = totalCom;
    }

    /**
     *
     * @return
     */
    public String getTotalNet() {
        return totalNet;
    }

    /**
     *
     * @param totalNet
     */
    public void setTotalNet(String totalNet) {
        this.totalNet = totalNet;
    }

    /**
     *
     * @return
     */
    public String getTotalBuy() {
        return totalBuy;
    }

    /**
     *
     * @param totalBuy
     */
    public void setTotalBuy(String totalBuy) {
        this.totalBuy = totalBuy;
    }

    /**
     *
     * @return
     */
    public String getTotalSpread() {
        return totalSpread;
    }

    /**
     *
     * @param totalSpread
     */
    public void setTotalSpread(String totalSpread) {
        this.totalSpread = totalSpread;
    }

    /**
     *
     * @return
     */
    public String getTotalComFix() {
        return totalComFix;
    }

    /**
     *
     * @param totalComFix
     */
    public void setTotalComFix(String totalComFix) {
        this.totalComFix = totalComFix;
    }

    /**
     *
     * @return
     */
    public String getKindClient() {
        return kindClient;
    }

    /**
     *
     * @param kindClient
     */
    public void setKindClient(String kindClient) {
        this.kindClient = kindClient;
    }

    /**
     *
     * @return
     */
    public String getCode() {
        return code;
    }

    /**
     *
     * @param code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return
     */
    public ArrayList<C_ChangeInternetBookingForBranches_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<C_ChangeInternetBookingForBranches_value> dati) {
        this.dati = dati;
    }

}
