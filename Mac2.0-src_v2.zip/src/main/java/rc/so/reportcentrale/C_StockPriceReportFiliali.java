/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

/**
 *
 * @author vcrugliano
 */
public class C_StockPriceReportFiliali {

//    cosco
    
//    public static void main(String[] args) {
//
//        OfficeStockPrice temp = new OfficeStockPrice();
//        ArrayList<OfficeStockPrice_value> elencoreportsingoli = new ArrayList<>();
//        
//        OfficeStockPrice_value pdf = new OfficeStockPrice_value();
//        pdf.setLocalcurrency("EUR");
//        ArrayList<OfficeStockPrice_value> dati = new ArrayList<>();
//        dati = Engine.getDatiOfficeStockPrice();
//        pdf.setId_filiale("079");
//        pdf.setDe_filiale("Milano Duomo");
//        pdf.setGruppo("MI");
//        pdf.setDati(dati);
//        elencoreportsingoli.add(pdf);
//
//        pdf = new OfficeStockPrice_value();
//        pdf.setLocalcurrency("EUR");
//        dati = new ArrayList<>();
//        dati = Engine.getDatiOfficeStockPrice();
//        pdf.setId_filiale("002");
//        pdf.setDe_filiale("Venezia Lista di Spagna");
//        pdf.setGruppo("VE");
//        pdf.setDati(dati);
//        elencoreportsingoli.add(pdf);
//                
//        pdf = new OfficeStockPrice_value();
//        pdf.setLocalcurrency("EUR");
//        dati = new ArrayList<>();
//        dati = Engine.getDatiOfficeStockPrice();
//        pdf.setId_filiale("003");
//        pdf.setDe_filiale("Venezia Rialto");
//        pdf.setGruppo("VE");
//        pdf.setDati(dati);
//        elencoreportsingoli.add(pdf);
//        
//        pdf = new OfficeStockPrice_value();
//        pdf.setLocalcurrency("EUR");
//        dati = new ArrayList<>();
//        dati = Engine.getDatiOfficeStockPrice();
//        pdf.setId_filiale("019");
//        pdf.setDe_filiale("Roma Termini");
//        pdf.setGruppo("RM");
//        pdf.setDati(dati);
//        elencoreportsingoli.add(pdf);
//        
//         pdf = new OfficeStockPrice_value();
//        pdf.setLocalcurrency("EUR");
//        dati = new ArrayList<>();
//        dati = Engine.getDatiOfficeStockPrice();
//        pdf.setId_filiale("019");
//        pdf.setDe_filiale("Roma Termini");
//        pdf.setGruppo("RM");
//        pdf.setDati(dati);
//        elencoreportsingoli.add(pdf);
//
//        ArrayList<String> alcolonne = new ArrayList<>();
//        alcolonne.add("Currency");
//        alcolonne.add("Kind");
//        alcolonne.add("Quantity");
//        alcolonne.add("Average buy");
//        alcolonne.add(Constant.localcurrency);
//               
//        temp.receiptcentrale(elencoreportsingoli, alcolonne);
//
//    }

}
