/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class C_TransactionRegisterSummary_value {

    String id_filiale, de_filiale, dataDa, dataA;

    ArrayList<C_TransactionRegisterSummary_value> dati;

    String purchnum, purchtot, purchcomm, salesnum, salestotal, salescomm, wusnum, wustot, wurnum, wurtot, stockbuynum, stockbuytot, stocksellnum, stockselltot, vatrefnum, vatrefundtot, onsinum, onsitot, onsonum, onsotot, cctot, cccomm;

    String tikinnum, tikintot, tikounum, tikoutot, insinnum, insintot, insounum, insoutot;

    String cashnum, cashtot, cashcomm;

    /**
     *
     * @return
     */
    public String getCashnum() {
        return cashnum;
    }

    /**
     *
     * @param cashnum
     */
    public void setCashnum(String cashnum) {
        this.cashnum = cashnum;
    }

    /**
     *
     * @return
     */
    public String getCashtot() {
        return cashtot;
    }

    /**
     *
     * @param cashtot
     */
    public void setCashtot(String cashtot) {
        this.cashtot = cashtot;
    }

    /**
     *
     * @return
     */
    public String getCashcomm() {
        return cashcomm;
    }

    /**
     *
     * @param cashcomm
     */
    public void setCashcomm(String cashcomm) {
        this.cashcomm = cashcomm;
    }

    /**
     *
     * @return
     */
    public String getTikinnum() {
        return tikinnum;
    }

    /**
     *
     * @param tikinnum
     */
    public void setTikinnum(String tikinnum) {
        this.tikinnum = tikinnum;
    }

    /**
     *
     * @return
     */
    public String getTikintot() {
        return tikintot;
    }

    /**
     *
     * @param tikintot
     */
    public void setTikintot(String tikintot) {
        this.tikintot = tikintot;
    }

    /**
     *
     * @return
     */
    public String getTikounum() {
        return tikounum;
    }

    /**
     *
     * @param tikounum
     */
    public void setTikounum(String tikounum) {
        this.tikounum = tikounum;
    }

    /**
     *
     * @return
     */
    public String getTikoutot() {
        return tikoutot;
    }

    /**
     *
     * @param tikoutot
     */
    public void setTikoutot(String tikoutot) {
        this.tikoutot = tikoutot;
    }

    /**
     *
     * @return
     */
    public String getInsinnum() {
        return insinnum;
    }

    /**
     *
     * @param insinnum
     */
    public void setInsinnum(String insinnum) {
        this.insinnum = insinnum;
    }

    /**
     *
     * @return
     */
    public String getInsintot() {
        return insintot;
    }

    /**
     *
     * @param insintot
     */
    public void setInsintot(String insintot) {
        this.insintot = insintot;
    }

    /**
     *
     * @return
     */
    public String getInsounum() {
        return insounum;
    }

    /**
     *
     * @param insounum
     */
    public void setInsounum(String insounum) {
        this.insounum = insounum;
    }

    /**
     *
     * @return
     */
    public String getInsoutot() {
        return insoutot;
    }

    /**
     *
     * @param insoutot
     */
    public void setInsoutot(String insoutot) {
        this.insoutot = insoutot;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public ArrayList<C_TransactionRegisterSummary_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<C_TransactionRegisterSummary_value> dati) {
        this.dati = dati;
    }

    /**
     *
     * @return
     */
    public String getPurchnum() {
        return purchnum;
    }

    /**
     *
     * @param purchnum
     */
    public void setPurchnum(String purchnum) {
        this.purchnum = purchnum;
    }

    /**
     *
     * @return
     */
    public String getPurchtot() {
        return purchtot;
    }

    /**
     *
     * @param purchtot
     */
    public void setPurchtot(String purchtot) {
        this.purchtot = purchtot;
    }

    /**
     *
     * @return
     */
    public String getPurchcomm() {
        return purchcomm;
    }

    /**
     *
     * @param purchcomm
     */
    public void setPurchcomm(String purchcomm) {
        this.purchcomm = purchcomm;
    }

    /**
     *
     * @return
     */
    public String getSalesnum() {
        return salesnum;
    }

    /**
     *
     * @param salesnum
     */
    public void setSalesnum(String salesnum) {
        this.salesnum = salesnum;
    }

    /**
     *
     * @return
     */
    public String getSalestotal() {
        return salestotal;
    }

    /**
     *
     * @param salestotal
     */
    public void setSalestotal(String salestotal) {
        this.salestotal = salestotal;
    }

    /**
     *
     * @return
     */
    public String getSalescomm() {
        return salescomm;
    }

    /**
     *
     * @param salescomm
     */
    public void setSalescomm(String salescomm) {
        this.salescomm = salescomm;
    }

    /**
     *
     * @return
     */
    public String getWusnum() {
        return wusnum;
    }

    /**
     *
     * @param wusnum
     */
    public void setWusnum(String wusnum) {
        this.wusnum = wusnum;
    }

    /**
     *
     * @return
     */
    public String getWustot() {
        return wustot;
    }

    /**
     *
     * @param wustot
     */
    public void setWustot(String wustot) {
        this.wustot = wustot;
    }

    /**
     *
     * @return
     */
    public String getWurnum() {
        return wurnum;
    }

    /**
     *
     * @param wurnum
     */
    public void setWurnum(String wurnum) {
        this.wurnum = wurnum;
    }

    /**
     *
     * @return
     */
    public String getWurtot() {
        return wurtot;
    }

    /**
     *
     * @param wurtot
     */
    public void setWurtot(String wurtot) {
        this.wurtot = wurtot;
    }

    /**
     *
     * @return
     */
    public String getStockbuynum() {
        return stockbuynum;
    }

    /**
     *
     * @param stockbuynum
     */
    public void setStockbuynum(String stockbuynum) {
        this.stockbuynum = stockbuynum;
    }

    /**
     *
     * @return
     */
    public String getStockbuytot() {
        return stockbuytot;
    }

    /**
     *
     * @param stockbuytot
     */
    public void setStockbuytot(String stockbuytot) {
        this.stockbuytot = stockbuytot;
    }

    /**
     *
     * @return
     */
    public String getStocksellnum() {
        return stocksellnum;
    }

    /**
     *
     * @param stocksellnum
     */
    public void setStocksellnum(String stocksellnum) {
        this.stocksellnum = stocksellnum;
    }

    /**
     *
     * @return
     */
    public String getStockselltot() {
        return stockselltot;
    }

    /**
     *
     * @param stockselltot
     */
    public void setStockselltot(String stockselltot) {
        this.stockselltot = stockselltot;
    }

    /**
     *
     * @return
     */
    public String getVatrefnum() {
        return vatrefnum;
    }

    /**
     *
     * @param vatrefnum
     */
    public void setVatrefnum(String vatrefnum) {
        this.vatrefnum = vatrefnum;
    }

    /**
     *
     * @return
     */
    public String getVatrefundtot() {
        return vatrefundtot;
    }

    /**
     *
     * @param vatrefundtot
     */
    public void setVatrefundtot(String vatrefundtot) {
        this.vatrefundtot = vatrefundtot;
    }

    /**
     *
     * @return
     */
    public String getOnsinum() {
        return onsinum;
    }

    /**
     *
     * @param onsinum
     */
    public void setOnsinum(String onsinum) {
        this.onsinum = onsinum;
    }

    /**
     *
     * @return
     */
    public String getOnsitot() {
        return onsitot;
    }

    /**
     *
     * @param onsitot
     */
    public void setOnsitot(String onsitot) {
        this.onsitot = onsitot;
    }

    /**
     *
     * @return
     */
    public String getOnsonum() {
        return onsonum;
    }

    /**
     *
     * @param onsonum
     */
    public void setOnsonum(String onsonum) {
        this.onsonum = onsonum;
    }

    /**
     *
     * @return
     */
    public String getOnsotot() {
        return onsotot;
    }

    /**
     *
     * @param onsotot
     */
    public void setOnsotot(String onsotot) {
        this.onsotot = onsotot;
    }

    /**
     *
     * @return
     */
    public String getCctot() {
        return cctot;
    }

    /**
     *
     * @param cctot
     */
    public void setCctot(String cctot) {
        this.cctot = cctot;
    }

    /**
     *
     * @return
     */
    public String getCccomm() {
        return cccomm;
    }

    /**
     *
     * @param cccomm
     */
    public void setCccomm(String cccomm) {
        this.cccomm = cccomm;
    }

}
