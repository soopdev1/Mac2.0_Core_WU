/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class C_ChangeMovimentForBranches_value {
    
    
    String id_filiale, de_filiale,dataDa,dataA;

    String currency, kind, qt, amount, percComm, comm, net, totBuy, spread, commFix; 
    
    ArrayList<C_ChangeMovimentForBranches_value> dati;

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return
     */
    public String getKind() {
        return kind;
    }

    /**
     *
     * @param kind
     */
    public void setKind(String kind) {
        this.kind = kind;
    }

    /**
     *
     * @return
     */
    public String getQt() {
        return qt;
    }

    /**
     *
     * @param qt
     */
    public void setQt(String qt) {
        this.qt = qt;
    }

    /**
     *
     * @return
     */
    public String getAmount() {
        return amount;
    }

    /**
     *
     * @param amount
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     *
     * @return
     */
    public String getPercComm() {
        return percComm;
    }

    /**
     *
     * @param percComm
     */
    public void setPercComm(String percComm) {
        this.percComm = percComm;
    }

    /**
     *
     * @return
     */
    public String getComm() {
        return comm;
    }

    /**
     *
     * @param comm
     */
    public void setComm(String comm) {
        this.comm = comm;
    }

    /**
     *
     * @return
     */
    public String getNet() {
        return net;
    }

    /**
     *
     * @param net
     */
    public void setNet(String net) {
        this.net = net;
    }

    /**
     *
     * @return
     */
    public String getTotBuy() {
        return totBuy;
    }

    /**
     *
     * @param totBuy
     */
    public void setTotBuy(String totBuy) {
        this.totBuy = totBuy;
    }

    /**
     *
     * @return
     */
    public String getSpread() {
        return spread;
    }

    /**
     *
     * @param spread
     */
    public void setSpread(String spread) {
        this.spread = spread;
    }

    /**
     *
     * @return
     */
    public String getCommFix() {
        return commFix;
    }

    /**
     *
     * @param commFix
     */
    public void setCommFix(String commFix) {
        this.commFix = commFix;
    }

    /**
     *
     * @return
     */
    public ArrayList<C_ChangeMovimentForBranches_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<C_ChangeMovimentForBranches_value> dati) {
        this.dati = dati;
    }

   
}
