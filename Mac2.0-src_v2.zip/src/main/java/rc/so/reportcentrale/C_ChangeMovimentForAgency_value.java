/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class C_ChangeMovimentForAgency_value {
     
    String id_filiale, de_filiale,dataDa,dataA;

    String branch, transaction, date, user, currency, kind, amount, percCom, com, nt, buy, spread, comFix, customerKind, delete, qty;
    
    String agency;
    
    ArrayList<C_Agency_value> dati;

    /**
     *
     * @return
     */
    public String getAgency() {
        return agency;
    }

    /**
     *
     * @param agency
     */
    public void setAgency(String agency) {
        this.agency = agency;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getBranch() {
        return branch;
    }

    /**
     *
     * @param branch
     */
    public void setBranch(String branch) {
        this.branch = branch;
    }

    /**
     *
     * @return
     */
    public String getTransaction() {
        return transaction;
    }

    /**
     *
     * @param transaction
     */
    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    /**
     *
     * @return
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param date
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return
     */
    public String getKind() {
        return kind;
    }

    /**
     *
     * @param kind
     */
    public void setKind(String kind) {
        this.kind = kind;
    }

    /**
     *
     * @return
     */
    public String getAmount() {
        return amount;
    }

    /**
     *
     * @param amount
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     *
     * @return
     */
    public String getPercCom() {
        return percCom;
    }

    /**
     *
     * @param percCom
     */
    public void setPercCom(String percCom) {
        this.percCom = percCom;
    }

    /**
     *
     * @return
     */
    public String getCom() {
        return com;
    }

    /**
     *
     * @param com
     */
    public void setCom(String com) {
        this.com = com;
    }

    /**
     *
     * @return
     */
    public String getNt() {
        return nt;
    }

    /**
     *
     * @param nt
     */
    public void setNt(String nt) {
        this.nt = nt;
    }

    /**
     *
     * @return
     */
    public String getBuy() {
        return buy;
    }

    /**
     *
     * @param buy
     */
    public void setBuy(String buy) {
        this.buy = buy;
    }

    /**
     *
     * @return
     */
    public String getSpread() {
        return spread;
    }

    /**
     *
     * @param spread
     */
    public void setSpread(String spread) {
        this.spread = spread;
    }

    /**
     *
     * @return
     */
    public String getComFix() {
        return comFix;
    }

    /**
     *
     * @param comFix
     */
    public void setComFix(String comFix) {
        this.comFix = comFix;
    }

    /**
     *
     * @return
     */
    public String getCustomerKind() {
        return customerKind;
    }

    /**
     *
     * @param customerKind
     */
    public void setCustomerKind(String customerKind) {
        this.customerKind = customerKind;
    }

    /**
     *
     * @return
     */
    public String getDelete() {
        return delete;
    }

    /**
     *
     * @param delete
     */
    public void setDelete(String delete) {
        this.delete = delete;
    }

    /**
     *
     * @return
     */
    public ArrayList<C_Agency_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<C_Agency_value> dati) {
        this.dati = dati;
    }

    /**
     *
     * @return
     */
    public String getQty() {
        return qty;
    }

    /**
     *
     * @param qty
     */
    public void setQty(String qty) {
        this.qty = qty;
    }

}
