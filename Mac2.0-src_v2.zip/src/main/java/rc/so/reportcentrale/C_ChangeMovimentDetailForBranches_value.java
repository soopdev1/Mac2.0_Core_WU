/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rc.so.reportcentrale;

import java.util.ArrayList;

/**
 *
 * @author srotella
 */
public class C_ChangeMovimentDetailForBranches_value {
     String id_filiale, de_filiale,dataDa,dataA;

    String branch, transaction, date, user, currency, kind, qty, amount, percCom,com, net, buy, spread, comFix, customer, delete, intBook; 
    
    String rate;
    
    ArrayList<C_ChangeMovimentDetailForBranches_value> dati;

    /**
     *
     * @return
     */
    public String getCom() {
        return com;
    }

    /**
     *
     * @param com
     */
    public void setCom(String com) {
        this.com = com;
    }

    /**
     *
     * @return
     */
    public String getRate() {
        return rate;
    }

    /**
     *
     * @param rate
     */
    public void setRate(String rate) {
        this.rate = rate;
    }

    /**
     *
     * @return
     */
    public String getId_filiale() {
        return id_filiale;
    }

    /**
     *
     * @param id_filiale
     */
    public void setId_filiale(String id_filiale) {
        this.id_filiale = id_filiale;
    }

    /**
     *
     * @return
     */
    public String getDe_filiale() {
        return de_filiale;
    }

    /**
     *
     * @param de_filiale
     */
    public void setDe_filiale(String de_filiale) {
        this.de_filiale = de_filiale;
    }

    /**
     *
     * @return
     */
    public String getDataDa() {
        return dataDa;
    }

    /**
     *
     * @param dataDa
     */
    public void setDataDa(String dataDa) {
        this.dataDa = dataDa;
    }

    /**
     *
     * @return
     */
    public String getDataA() {
        return dataA;
    }

    /**
     *
     * @param dataA
     */
    public void setDataA(String dataA) {
        this.dataA = dataA;
    }

    /**
     *
     * @return
     */
    public String getBranch() {
        return branch;
    }

    /**
     *
     * @param branch
     */
    public void setBranch(String branch) {
        this.branch = branch;
    }

    /**
     *
     * @return
     */
    public String getTransaction() {
        return transaction;
    }

    /**
     *
     * @param transaction
     */
    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    /**
     *
     * @return
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param date
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return
     */
    public String getKind() {
        return kind;
    }

    /**
     *
     * @param kind
     */
    public void setKind(String kind) {
        this.kind = kind;
    }

    /**
     *
     * @return
     */
    public String getQty() {
        return qty;
    }

    /**
     *
     * @param qty
     */
    public void setQty(String qty) {
        this.qty = qty;
    }

    /**
     *
     * @return
     */
    public String getAmount() {
        return amount;
    }

    /**
     *
     * @param amount
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     *
     * @return
     */
    public String getPercCom() {
        return percCom;
    }

    /**
     *
     * @param percCom
     */
    public void setPercCom(String percCom) {
        this.percCom = percCom;
    }

    /**
     *
     * @return
     */
    public String getNet() {
        return net;
    }

    /**
     *
     * @param net
     */
    public void setNet(String net) {
        this.net = net;
    }

    /**
     *
     * @return
     */
    public String getBuy() {
        return buy;
    }

    /**
     *
     * @param buy
     */
    public void setBuy(String buy) {
        this.buy = buy;
    }

    /**
     *
     * @return
     */
    public String getSpread() {
        return spread;
    }

    /**
     *
     * @param spread
     */
    public void setSpread(String spread) {
        this.spread = spread;
    }

    /**
     *
     * @return
     */
    public String getComFix() {
        return comFix;
    }

    /**
     *
     * @param comFix
     */
    public void setComFix(String comFix) {
        this.comFix = comFix;
    }

    /**
     *
     * @return
     */
    public String getCustomer() {
        return customer;
    }

    /**
     *
     * @param customer
     */
    public void setCustomer(String customer) {
        this.customer = customer;
    }

    /**
     *
     * @return
     */
    public String getDelete() {
        return delete;
    }

    /**
     *
     * @param delete
     */
    public void setDelete(String delete) {
        this.delete = delete;
    }

    /**
     *
     * @return
     */
    public String getIntBook() {
        return intBook;
    }

    /**
     *
     * @param intBook
     */
    public void setIntBook(String intBook) {
        this.intBook = intBook;
    }

    /**
     *
     * @return
     */
    public ArrayList<C_ChangeMovimentDetailForBranches_value> getDati() {
        return dati;
    }

    /**
     *
     * @param dati
     */
    public void setDati(ArrayList<C_ChangeMovimentDetailForBranches_value> dati) {
        this.dati = dati;
    }

 
}
